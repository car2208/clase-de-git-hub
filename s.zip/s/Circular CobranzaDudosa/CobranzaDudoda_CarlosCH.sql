ALTER PROCEDURE dbo.usp_ProcesoCobranzaDudosa
@baseproceso varchar(100)
AS 
BEGIN
DECLARE @MES SMALLINT,@FECHAACTUAL DATE,@A�O SMALLINT,@MESES SMALLINT

SET @A�O=YEAR(GETDATE())
SELECT @MES=MAX(MES) FROM DB_GPGD.DBO.TBR_Saldos_Valores_Pendientes WHERE A�O=@A�O
SET @FECHAACTUAL=GETDATE()
SET @MESES=48


PRINT '***********************DESCARGANDO UNIVERSO DE VALORES PARA PROCESAMIENTO*********************************'

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [type]='U' and schema_id=1 and name='AND_SALDOS_VALORES_PENDIENTES')
	BEGIN 
		DROP TABLE DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES 
	END
	ELSE
	BEGIN
		SELECT * INTO DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES
		FROM DB_GPGD.DBO.TBR_Saldos_Valores_Pendientes WHERE A�O=@A�O AND MES=@MES
	END


PRINT  '*************************EXLUSIONES*************************************************'

IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [type]='U' and schema_id=1 and name='AND_SALDOS_VALORES_PENDIENTES_0')
	BEGIN 
		DROP TABLE DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_0
	END
ELSE 
    BEGIN 
		SELECT * INTO DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_0
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES WITH (NOLOCK)
		WHERE DATEDIFF(MONTH,fec_coa,@FECHAACTUAL)>@MESES
		AND (sal_trib+sal_int+sal_cap+sal_rec)>0 AND etapa_bas='03' AND cod_doc IN
			(
			SELECT DISTINCT cod_doc FROM DB_GPGD.DBO.Param_Tipo_DOC WITH (NOLOCK) 
			WHERE tipo IN ('OP', 'RD', 'RM', 'RIP')
			)
	END

/******************************************************************************************************************************/

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [type]='U' and schema_id=1 and name='AND_SALDOS_VALORES_PENDIENTES_1')
		BEGIN 
			DROP TABLE DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_1
		END
	ELSE 
		BEGIN 
			SELECT * INTO DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_1
			FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_0  WITH (NOLOCK)
		END


	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [type]='U' and schema_id=1 and name='AND_SALDOS_VALORES_PENDIENTES_2')
	 BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2
	 END
	ELSE 
	 BEGIN
		SELECT CIC, RUC, SUM(sal_trib+sal_int+sal_cap+sal_rec) AS DEUDA,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_A,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_B,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_C,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_1,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_2,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_3,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_4,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_5,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_6,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_7,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_8,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_II_A,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_II_B,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_II_C,
		CONVERT(VARCHAR(1),'') AS TIP_EXC_2_II_D
		INTO DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_1 WITH (NOLOCK)
		GROUP BY CIC, RUC
	 END

	--EXPORTAR

	--SELECT CIC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_0_back A
	--WHERE CIC NOT IN 
	--	(
	--	SELECT CIC
	--	FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_0
	--	GROUP BY CIC
	--	) 
	--GROUP BY CIC


	--SELECT CIC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 GROUP BY CIC

PRINT ('/****************************************************************************************************/')
PRINT ('---EXCLUSIONES DEUDORES ')
PRINT ('/****************************************************************************************************/')


PRINT ('--A)--2� Que est� en Procedimiento Concursal o Reorganizaci�n de sociedades. ')

IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND name='AND_INF_PC')
	BEGIN 
	   DROP TABLE DB_PROC_CDP.DBO.AND_INF_PC
	END 
ELSE
   BEGIN
	   SELECT RUC INTO DB_PROC_CDP.DBO.AND_INF_PC
	   FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES
	   WHERE etapa_alt='15'
	   GROUP BY RUC	

	   UPDATE A
	   SET TIP_EXC_2_A='X'
	   FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
	   INNER JOIN DB_PROC_CDP.DBO.AND_INF_PC  B
	   ON A.RUC=B.RUC
   END


------------------------------------------------------------------------------------------------------------------------------------
PRINT ('--B--2� Que est� en Procedimiento de Reorganizaci�n de sociedades. ')
PRINT ('========>No se proces� no hay informaci�n')
------------------------------------------------------------------------------------------------------------------------------------

PRINT ('--C --3� Que tenga una RD de atribuci�n de responsabilidad solidaria activa')

IF EXISTS( SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_INF_RD')
	BEGIN 
		DROP TABLE DB_PROC_CDP.DBO.AND_INF_RD
	END
ELSE 
BEGIN
	SELECT RUC INTO DB_PROC_CDP.DBO.AND_INF_RD
	FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES
	WHERE cod_doc IN ('004000','004020','004010')
	GROUP BY RUC

	UPDATE A
	SET TIP_EXC_2_C='X'
	FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
	INNER JOIN DB_PROC_CDP.DBO.AND_INF_RD  B
	ON A.RUC=B.RUC
END


PRINT ('/****************************************************************************************************/')
PRINT ('--EXCLUSIONES DEUDORES PROCESOS DESCENTRALIZADOS - movimiento en 24 meses '+CONVERT(CHAR(10),@FECHAACTUAL))
PRINT('/****************************************************************************************************/')
------------------------------------------------------------------------------------------------------------------------------------

PRINT('--I - A - 1 --1� Que tenga o haya tenido valores emitidos (en cualquier estado)')
 
	
IF EXISTS( SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='TBL_Valores_Emitidos_0')
	BEGIN
 		DROP TABLE DB_PROC_CDP.DBO.TBL_Valores_Emitidos_0
	END
ELSE 
	BEGIN
		SELECT RUC 	INTO DB_PROC_CDP.DBO.TBL_Valores_Emitidos_0
		FROM DB_GPGD.DBO.TBL_Valores_Emitidos
		WHERE DATEDIFF(MONTH,  fec_emi, @FECHAACTUAL)<=24
		GROUP BY RUC

		UPDATE A
		SET TIP_EXC_2_I_1='X'
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
		INNER JOIN DB_PROC_CDP.DBO.TBL_Valores_Emitidos_0  B
		ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS
	END


------------------------------------------------------------------------------------------------------------------------------------
PRINT ('------------------------------I - A - 2--no hay----------------------------')


PRINT ('-----------------------------PAGOS PERIODO 2014--------------------------')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_PAGOS_MULTA')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_PAGOS_MULTA
	END
	ELSE
	BEGIN
		SELECT * INTO DB_PROC_CDP.DBO.AND_PAGOS_MULTA
		FROM DB_TERADATA.DBO.vw_pagos_per2014
		WHERE CIC IN (SELECT CIC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 WHERE CIC<>0)

		PRINT ('-----------------------------PAGOS PERIODO 2015--------------------------')

		INSERT INTO DB_PROC_CDP.DBO.AND_PAGOS_MULTA
		SELECT * FROM DB_TERADATA.DBO.vw_pagos_per2015
		WHERE CIC IN (SELECT CIC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 WHERE CIC<>0)

		PRINT ('-----------------------------PAGOS PERIODO 2016--------------------------')

		INSERT INTO DB_PROC_CDP.DBO.AND_PAGOS_MULTA
		SELECT * FROM DB_TERADATA.DBO.vw_pagos_per2016
		WHERE CIC IN (SELECT CIC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 WHERE CIC<>0)

		PRINT ('--------------------------------------------------------------------------')
	END



	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_PAGOS_MULTA_0')
	BEGIN 
	DROP TABLE DB_PROC_CDP.DBO.AND_PAGOS_MULTA_0
	END
	ELSE 
	BEGIN
		SELECT num_doc AS RUC INTO DB_PROC_CDP.DBO.AND_PAGOS_MULTA_0 
		FROM DB_PROC_CDP.DBO.AND_PAGOS_MULTA
		WHERE DATEDIFF(MONTH,  f_presenta,@FECHAACTUAL)<=24
		AND num_doc IN (SELECT RUC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		AND valor_casilla>0
		GROUP BY num_doc

		UPDATE A
		SET TIP_EXC_2_I_2='X'
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
		INNER JOIN DB_PROC_CDP.DBO.AND_PAGOS_MULTA_0  B
		ON A.RUC=B.RUC
	END

PRINT ('-----------------------------------------------------------------------------------------------------------------------')
PRINT ('--I - A - 3------------------------------------------------------------------------------------------------------------')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='gpgd_solic_fracc_resueltas_0')
	BEGIN 
		DROP TABLE DB_PROC_CDP.DBO.gpgd_solic_fracc_resueltas_0
	END
	ELSE 
	BEGIN
		SELECT RUC INTO DB_PROC_CDP.DBO.gpgd_solic_fracc_resueltas_0
		FROM DB_GPGD.DBO.gpgd_solic_fracc_resueltas
		WHERE DATEDIFF(MONTH,  fec_rin,@FECHAACTUAL)<=24
		AND cod_doc IN ('017117','017701','017500','017001')
		GROUP BY RUC

		UPDATE A
		SET TIP_EXC_2_I_3='X'
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
		INNER JOIN DB_PROC_CDP.DBO.gpgd_solic_fracc_resueltas_0  B
		ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS
	END


PRINT ('----------------------------------------------------------------------------------------------------------------------')
PRINT ('--I - A - 4 --NO HAY')
PRINT ('-----------------------------------------------------------------------------------------------------------------------')

PRINT (CHAR(10)+'--------I - A - 5 --4� Que hayan obtenido autorizaci�n de impresi�n CdP---------------------------------------------') 

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_AUTORIZA_CPE')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_AUTORIZA_CPE
	END
	ELSE
	BEGIN
		SELECT RUC 	INTO DB_PROC_CDP.DBO.AND_AUTORIZA_CPE
		FROM DB_PADRON.DBO.Tbl_gpgf_autorizacion_cdp
		WHERE DATEDIFF(MONTH,fec_autoriz, @FECHAACTUAL)<=24
		GROUP BY RUC

		UPDATE A
		SET TIP_EXC_2_I_5='X'
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
		INNER JOIN DB_PROC_CDP.DBO.AND_AUTORIZA_CPE  B
		ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS

		TRUNCATE TABLE db_proc_cdp.dbo.cic_ruc_saldos_valores
		INSERT INTO db_proc_cdp.dbo.cic_ruc_saldos_valores
		SELECT DISTINCT cic,ruc FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2

	END	

END

EXEC db_proc_cdp.dbo.usp_ProcesoCobranzaDudosa ''

/*****************************************************************************************************************************/
/*****************************************************************************************************************************/
/*****************************************************************************************************************************/
/*****************************************************************************************************************************/

PRINT ('---------------------------------------------------------------------------------------------------------------------')
PRINT ('--------I - A - 6 --4� Que hayan emitido Comprobante de Pago Electr�nico'+CHAR(10))

	DROP TABLE DB_PROC_CDP.DBO.t5938cabcpe
	SELECT TOP 0 * INTO DB_PROC_CDP.DBO.t5938cabcpe
	FROM OPENQUERY(DEANDRE,
	'SELECT FIRST 1	
		x0.cod_tipocomp ,x0.num_ruc ,x0.num_seriecpe ,x0.num_cpe ,
		x0.cod_moneda ,x0.num_establec ,x0.cod_cic,
		x0.num_docidenti ,x0.cod_tipidenti ,
		x0.cod_tipocpe ,x0.fec_emicpe 
	 FROM sif:"admdwh".t5938cabcpe X0
	')


	DROP TABLE DB_PROC_CDP.DBO.t5938cabcpe_0
	SELECT num_ruc AS RUC
	INTO DB_PROC_CDP.DBO.t5938cabcpe_0
	FROM DB_PROC_CDP.DBO.t5938cabcpe
	WHERE DATEDIFF(MONTH,  fec_emicpe,@FECHAACTUAL)<=24
	GROUP BY num_ruc


	UPDATE A
	SET TIP_EXC_2_I_6='X'
	FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
	INNER JOIN DB_PROC_CDP.DBO.t5938cabcpe_0  B
	ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS



PRINT('--------------------------------------------------------------------------------------------------')
PRINT('---------------------------------------------I - A - 7--------------------------------------------')

PRINT('/***********************************************0621*********************************************/')

PRINT ('---------------1 �	Declara F�cil - Formulario Virtual N� 621 IGV Renta Mensual-------------------')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [type]='U' AND SCHEMA_ID=1 AND NAME='AND_CASILLA_0621')
		BEGIN
			DROP TABLE DB_PROC_CDP.DBO.AND_CASILLA_0621
		END
		ELSE
		BEGIN
			SELECT cod_casilla AS CASILLA
			INTO DB_PROC_CDP.DBO.AND_CASILLA_0621
			FROM DB_PROC_CDP.DBO.d2784dimnem_NO_ELIMINAR A
			INNER JOIN DB_PROC_CDP.DBO.p2813casilla_NO_ELIMINAR B ON A.cod_nemotec=B.cod_nemotec
			WHERE B.cod_formul='0621' AND B.ind_tipdato='N' AND SUBSTRING(B.cod_nemotec,1,3)='mto'
		END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [type]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0621')
		BEGIN
			DROP TABLE DB_PROC_CDP.DBO.AND_DET_0621
		END
	ELSE 
		BEGIN
			SELECT * INTO DB_PROC_CDP.DBO.AND_DET_0621
			FROM DB_TERADATA.DBO.POC_IGV_DET_F0621
			WHERE n_doc_declado IN 
			(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
			AND PERIODO>='201401'
		END
		
	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [type]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0621_0')		
		BEGIN
			DROP TABLE DB_PROC_CDP.DBO.AND_DET_0621_0
		END
	ELSE
		BEGIN
				SELECT n_doc_declado AS RUC,
				SUM(CASE 
					WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 OR valor_casilla='.' 
					THEN '0' ELSE valor_casilla END),'0')) > 0
				THEN 1 
				ELSE 0 END) AS IND_MTO
				INTO DB_PROC_CDP.DBO.AND_DET_0621_0
				FROM DB_PROC_CDP.DBO.AND_DET_0621
				WHERE CASILLA IN (SELECT CASILLA FROM DB_PROC_CDP.DBO.AND_CASILLA_0621) 
				AND PERIODO BETWEEN '201401' AND '201612'
				AND cod_veredito NOT IN (2,4)
				AND DATEDIFF(MONTH,f_presenta,@FECHAACTUAL)<=24
				GROUP BY n_doc_declado
		END
		
	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [type]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0621_1')		
		BEGIN
			DROP TABLE DB_PROC_CDP.DBO.AND_DET_0621_1
		END
	ELSE
		BEGIN
			SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_0621
			INTO DB_PROC_CDP.DBO.AND_DET_0621_1
			FROM DB_PROC_CDP.DBO.AND_DET_0621_0
			GROUP BY RUC
		END
		
		
--OK--REVISAR SI ALGUNA CASILLA TIENE UN VALOR EXTRA�O

PRINT ('/***********************************************0626**********************************************************/')

PRINT ('---2 �	Declara F�cil - Formulario Virtual N� 626 Agentes de Retenci�n----------------------------------------')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [type]='U' AND SCHEMA_ID=1 AND NAME='AND_CASILLA_0626')
		BEGIN 
			DROP TABLE DB_PROC_CDP.DBO.AND_CASILLA_0626
		END
	ELSE
		BEGIN
			SELECT cod_casilla AS CASILLA
			INTO DB_PROC_CDP.DBO.AND_CASILLA_0626
			FROM DB_PROC_CDP.DBO.d2784dimnem_NO_ELIMINAR A
			INNER JOIN DB_PROC_CDP.DBO.p2813casilla_NO_ELIMINAR B
			ON A.cod_nemotec=B.cod_nemotec
			WHERE B.cod_formul='0626'
			AND B.ind_tipdato='N'
			AND SUBSTRING(B.cod_nemotec,1,3)='mto'
	END


/*
select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0626" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("404","401","403","503","405","402","410","502","511","512","514"))
AND cod_veredito NOT IN ("2","4")
--127174 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_0626_TODO_F.TXT (704.40 secs)
--119494 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_0626.TXT (3753.88 secs)

DROP TABLE DB_PROC_CDP.DBO.AND_DET_0626
SELECT 
TOP 0 *
INTO DB_PROC_CDP.DBO.AND_DET_0626
FROM OPENQUERY(DEANDRE,
'select FIRST 1 x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0626" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("404","401","403","503","405","402","410","502","511","512","514"))
AND cod_veredito NOT IN ("2","4")
')
*/

TRUNCATE TABLE DB_PROC_CDP.DBO.AND_DET_0626
INSERT INTO DB_PROC_CDP.DBO.AND_DET_0626
SELECT * FROM OPENQUERY(DEANDRE,
'select  x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0626" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("404","401","403","503","405","402","410","502","511","512","514"))
AND cod_veredito NOT IN ("2","4")
')
--SQL executed OK. Number of rows affected=0 (0.68 secs)
--(31130 row(s) affected)

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0626_0')
BEGIN
	DROP TABLE DB_PROC_CDP.DBO.AND_DET_0626_0
END
ELSE
BEGIN
	SELECT n_doc_declado AS RUC,SUM(CASE 
	WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
	THEN 1 
	ELSE 0 END) AS IND_MTO
	INTO DB_PROC_CDP.DBO.AND_DET_0626_0
	FROM DB_PROC_CDP.DBO.AND_DET_0626
	WHERE CASILLA IN (SELECT CASILLA FROM DB_PROC_CDP.DBO.AND_CASILLA_0626)
	AND PERIODO BETWEEN '201401' AND '201612'
	AND DATEDIFF(MONTH,  f_presenta, '13-12-2016')<=24
	GROUP BY n_doc_declado
END

--OK--REVISAR SI ALGUNA CASILLA TIENE UN VALOR EXTRA�O

IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0626_1')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_0626_1
	END
	ELSE
	BEGIN
		SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_0626
		INTO DB_PROC_CDP.DBO.AND_DET_0626_1
		FROM DB_PROC_CDP.DBO.AND_DET_0626_0
		GROUP BY RUC
	END


PRINT ('/***************************0633******************************/')
PRINT ('--3 �	Declara F�cil - Formulario Virtual N� 633 Agentes de Percepci�n Hidrocarburos--------')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID='1' AND NAME='AND_CASILLA_0633'  )
		BEGIN
			DROP TABLE DB_PROC_CDP.DBO.AND_CASILLA_0633
		END
	ELSE
		BEGIN
			SELECT cod_casilla AS CASILLA
			INTO DB_PROC_CDP.DBO.AND_CASILLA_0633
			FROM DB_PROC_CDP.DBO.d2784dimnem_NO_ELIMINAR A
			INNER JOIN DB_PROC_CDP.DBO.p2813casilla_NO_ELIMINAR B
			ON A.cod_nemotec=B.cod_nemotec
			WHERE B.cod_formul='0633'
			AND B.ind_tipdato='N'
			AND SUBSTRING(B.cod_nemotec,1,3)='mto'
		END
/*
select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0633" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("410","403","404","402","405","503","401","502"))
AND cod_veredito NOT IN ("2","4")
--594 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_0633.TXT (3240.12 secs)

DROP TABLE DB_PROC_CDP.DBO.AND_DET_0633
SELECT 
TOP 0 *
INTO DB_PROC_CDP.DBO.AND_DET_0633
FROM OPENQUERY(DEANDRE,
'select FIRST 1 x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0633" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("410","403","404","402","405","503","401","502"))
AND cod_veredito NOT IN ("2","4")
')
*/

TRUNCATE TABLE DB_PROC_CDP.DBO.AND_DET_0633
INSERT INTO DB_PROC_CDP.DBO.AND_DET_0633
SELECT * FROM OPENQUERY(DEANDRE,
'select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0633" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("410","403","404","402","405","503","401","502"))
AND cod_veredito NOT IN ("2","4")
')
--(477 row(s) affected)

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0633_0')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_0633_0
	END
	ELSE
	BEGIN
		SELECT n_doc_declado AS RUC,
		SUM(CASE 
		WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
		THEN 1 
		ELSE 0 END) AS IND_MTO
		INTO DB_PROC_CDP.DBO.AND_DET_0633_0
		FROM DB_PROC_CDP.DBO.AND_DET_0633
		WHERE CASILLA IN (SELECT CASILLA FROM DB_PROC_CDP.DBO.AND_CASILLA_0633)
		AND PERIODO BETWEEN '201401' AND '201612'
		AND DATEDIFF(MONTH,  f_presenta, '13-12-2016')<=24
		GROUP BY n_doc_declado
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0633_1')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_0633_1
	END
	ELSE
	BEGIN
		SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_0633
		INTO DB_PROC_CDP.DBO.AND_DET_0633_1
		FROM DB_PROC_CDP.DBO.AND_DET_0633_0
		GROUP BY RUC
	END


PRINT ('/********************************************0697*****************************************/')
PRINT ('--4 �	Declara F�cil - Formulario Virtual N� 697 Agentes de Percepci�n Ventas Internas.')

IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_CASILLA_0697')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_CASILLA_0697
	END
	ELSE
	BEGIN

		SELECT cod_casilla AS CASILLA
		INTO DB_PROC_CDP.DBO.AND_CASILLA_0697
		FROM DB_PROC_CDP.DBO.d2784dimnem_NO_ELIMINAR A
		INNER JOIN DB_PROC_CDP.DBO.p2813casilla_NO_ELIMINAR B
		ON A.cod_nemotec=B.cod_nemotec
		WHERE B.cod_formul='0697'
		AND B.ind_tipdato='N'
		AND SUBSTRING(B.cod_nemotec,1,3)='mto'

	END
	/*
	select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
	x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
	from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
	where (x0.cod_formul = "0697" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
	AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
	AND x1.cod_casilla IN ("401","402","403","404","405","410","502","503"))
	AND cod_veredito NOT IN ("2","4")
	--44190 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_0697.TXT (3213.30 secs)

	DROP TABLE DB_PROC_CDP.DBO.AND_DET_0697
	SELECT 
	TOP 0 *
	INTO DB_PROC_CDP.DBO.AND_DET_0697
	FROM OPENQUERY(DEANDRE,
	'select FIRST 1 x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
	x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
	from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
	where (x0.cod_formul = "0697" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
	AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
	AND x1.cod_casilla IN ("401","402","403","404","405","410","502","503"))
	AND cod_veredito NOT IN ("2","4")
	')
	*/
	TRUNCATE TABLE DB_PROC_CDP.DBO.AND_DET_0697
	INSERT INTO DB_PROC_CDP.DBO.AND_DET_0697
	SELECT 
	*
	FROM OPENQUERY(DEANDRE,
	'select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,
	x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
	x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
	from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
	where (x0.cod_formul = "0697" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
	AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
	AND x1.cod_casilla IN ("401","402","403","404","405","410","502","503"))
	AND cod_veredito NOT IN ("2","4")
	')
	--(4790 row(s) affected)

	IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0697_0')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_0697_0
	END
	BEGIN
		SELECT n_doc_declado AS RUC,
		SUM(CASE 
		WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
		THEN 1 
		ELSE 0 END) AS IND_MTO
		INTO DB_PROC_CDP.DBO.AND_DET_0697_0
		FROM DB_PROC_CDP.DBO.AND_DET_0697
		WHERE CASILLA IN (SELECT CASILLA FROM DB_PROC_CDP.DBO.AND_CASILLA_0697)
		AND PERIODO BETWEEN '201401' AND '201612'
		AND DATEDIFF(MONTH,  f_presenta, '13-12-2016')<=24
		GROUP BY n_doc_declado
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0697_1' )
	BEGIN 
		 DROP TABLE DB_PROC_CDP.DBO.AND_DET_0697_1
	END
	ELSE
	BEGIN
		SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_0697
		INTO DB_PROC_CDP.DBO.AND_DET_0697_1
		FROM DB_PROC_CDP.DBO.AND_DET_0697_0
		GROUP BY RUC
	END

PRINT ('/***************************************************************************************************/')
PRINT ('/*********************************RENTA ANUAL 2 A�OS ANTES-- 0701,0691******************************/')
PRINT ('--5 �	Declaraci�n de Renta Anual de Personas Naturales.')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_CASILLA_0691' )
	BEGIN 
		DROP TABLE DB_PROC_CDP.DBO.AND_CASILLA_0691
	END
	ELSE
	BEGIN
		SELECT cod_casilla AS CASILLA
		INTO DB_PROC_CDP.DBO.AND_CASILLA_0691
		FROM DB_PROC_CDP.DBO.d2784dimnem_NO_ELIMINAR A
		INNER JOIN DB_PROC_CDP.DBO.p2813casilla_NO_ELIMINAR B
		ON A.cod_nemotec=B.cod_nemotec
		WHERE B.cod_formul='0691'
		AND B.ind_tipdato='N'
		AND SUBSTRING(B.cod_nemotec,1,3)='mto'
	END

--OK

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_CASILLA_0701')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_CASILLA_0701
	END
	ELSE
	BEGIN
		SELECT cod_casilla AS CASILLA
		INTO DB_PROC_CDP.DBO.AND_CASILLA_0701
		FROM DB_PROC_CDP.DBO.d2784dimnem_NO_ELIMINAR A
		INNER JOIN DB_PROC_CDP.DBO.p2813casilla_NO_ELIMINAR B
		ON A.cod_nemotec=B.cod_nemotec
		WHERE B.cod_formul='0701'
		AND B.ind_tipdato='N'
		AND SUBSTRING(B.cod_nemotec,1,3)='mto'

	END
	
--OK
	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0691')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_0691
	END
	ELSE
	BEGIN
		SELECT *
		INTO DB_PROC_CDP.DBO.AND_DET_0691
		FROM DB_TERADATA.DBO.POC_RENTA_DET_F0691
		WHERE n_doc_declado IN 
		(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		AND PERIODO>='201401'
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0701')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_0701
	END
	ELSE
	BEGIN
		SELECT *
		INTO DB_PROC_CDP.DBO.AND_DET_0701
		FROM DB_TERADATA.DBO.POC_RENTA_DET_F0701
		WHERE n_doc_declado IN 
		(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		AND PERIODO>='201401'
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_RT_PN')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_RT_PN
	END
	ELSE
	BEGIN
		SELECT n_doc_declado AS RUC,
		SUM(CASE WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
		THEN 1 
		ELSE 0 END) AS IND_MTO
		INTO DB_PROC_CDP.DBO.AND_DET_RT_PN
		FROM DB_PROC_CDP.DBO.AND_DET_0691
		WHERE CASILLA COLLATE SQL_Latin1_General_CP1_CI_AS 
		IN (SELECT CASILLA FROM DB_PROC_CDP.DBO.AND_CASILLA_0691)
		AND PERIODO BETWEEN '201401' AND '201612'
		AND cod_veredito NOT IN (2,4)
		AND DATEDIFF(MONTH,  f_presenta, '13-12-2016')<=24
		GROUP BY n_doc_declado

		INSERT INTO DB_PROC_CDP.DBO.AND_DET_RT_PN
		SELECT n_doc_declado AS RUC,
		SUM(CASE 
		WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
		THEN 1 
		ELSE 0 END) AS IND_MTO
		FROM DB_PROC_CDP.DBO.AND_DET_0701
		WHERE CASILLA COLLATE SQL_Latin1_General_CP1_CI_AS IN (SELECT CASILLA FROM DB_PROC_CDP.DBO.AND_CASILLA_0701)
		AND PERIODO BETWEEN '201401' AND '201612'
		AND cod_veredito NOT IN (2,4)
		AND DATEDIFF(MONTH,  f_presenta, '13-12-2016')<=24
		GROUP BY n_doc_declado
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_RT_PN_1')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_RT_PN_1
	END
	ELSE
	BEGIN
		SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_RTA_PN
		INTO DB_PROC_CDP.DBO.AND_DET_RT_PN_1
		FROM DB_PROC_CDP.DBO.AND_DET_RT_PN
		GROUP BY RUC
	END

PRINT('/***************************RENTA ANUAL 2 A�OS ANTES-- 0702,0692******************************/')
PRINT('--6 �	Declaraci�n Renta Anual  � Tercera Categor�a  ')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_CASILLA_0692')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_CASILLA_0692
	END
	ELSE
	BEGIN
		SELECT cod_casilla AS CASILLA
		INTO DB_PROC_CDP.DBO.AND_CASILLA_0692
		FROM DB_PROC_CDP.DBO.d2784dimnem_NO_ELIMINAR A
		INNER JOIN DB_PROC_CDP.DBO.p2813casilla_NO_ELIMINAR B
		ON A.cod_nemotec=B.cod_nemotec
		WHERE B.cod_formul='0692'
		AND B.ind_tipdato='N'
		AND SUBSTRING(B.cod_nemotec,1,3)='mto'
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_CASILLA_0702')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_CASILLA_0702
	END
	ELSE
	BEGIN
		SELECT cod_casilla AS CASILLA
		INTO DB_PROC_CDP.DBO.AND_CASILLA_0702
		FROM DB_PROC_CDP.DBO.d2784dimnem_NO_ELIMINAR A
		INNER JOIN DB_PROC_CDP.DBO.p2813casilla_NO_ELIMINAR B
		ON A.cod_nemotec=B.cod_nemotec
		WHERE B.cod_formul='0702'
		AND B.ind_tipdato='N'
		AND SUBSTRING(B.cod_nemotec,1,3)='mto'
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0692')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_0692
	END
	ELSE 
	BEGIN
		SELECT *
		INTO DB_PROC_CDP.DBO.AND_DET_0692
		FROM DB_TERADATA.DBO.POC_RENTA_DET_F0692
		WHERE n_doc_declado IN 
		(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		AND PERIODO>='201401'
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_0702')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_0702
	END
	ELSE
	BEGIN
		SELECT *
		INTO DB_PROC_CDP.DBO.AND_DET_0702
		FROM DB_TERADATA.DBO.POC_RENTA_DET_F0702
		WHERE n_doc_declado IN 
		(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		AND PERIODO>='201401'
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_RT_PJ')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_RT_PJ
	END
	ELSE 
	BEGIN
		SELECT n_doc_declado AS RUC,
		SUM(CASE 
		WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
		THEN 1 
		ELSE 0 END) AS IND_MTO
		INTO DB_PROC_CDP.DBO.AND_DET_RT_PJ
		FROM DB_PROC_CDP.DBO.AND_DET_0692
		WHERE CASILLA COLLATE SQL_Latin1_General_CP1_CI_AS IN (SELECT CASILLA FROM DB_PROC_CDP.DBO.AND_CASILLA_0692)
		AND PERIODO BETWEEN '201401' AND '201612'
		AND cod_veredito NOT IN (2,4)
		AND DATEDIFF(MONTH,  f_presenta, '13-12-2016')<=24
		GROUP BY n_doc_declado


		INSERT INTO DB_PROC_CDP.DBO.AND_DET_RT_PJ
		SELECT n_doc_declado AS RUC,
		SUM(CASE 
		WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
		THEN 1 
		ELSE 0 END) AS IND_MTO
		FROM DB_PROC_CDP.DBO.AND_DET_0702
		WHERE CASILLA COLLATE SQL_Latin1_General_CP1_CI_AS IN (SELECT CASILLA FROM DB_PROC_CDP.DBO.AND_CASILLA_0702)
		AND PERIODO BETWEEN '201401' AND '201612'
		AND cod_veredito NOT IN (2,4)
		AND DATEDIFF(MONTH,  f_presenta, '13-12-2016')<=24
		GROUP BY n_doc_declado
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_RT_PJ_1')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_RT_PJ_1
	END
	ELSE
	BEGIN
		SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_RTA_PJ
		INTO DB_PROC_CDP.DBO.AND_DET_RT_PJ_1
		FROM DB_PROC_CDP.DBO.AND_DET_RT_PJ
		GROUP BY RUC
	END


PRINT ('/******************************************************ITF***********************************************/')
PRINT ('--7 �	Declaraci�n del Impuesto a las Transacciones Financieras - ITF. No hay restricci�n al tipo de movimiento ni al tipo de operaci�n.')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_INF_ITF')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_INF_ITF
	END
	ELSE
	BEGIN
		SELECT 
		cic_declado AS CIC, 
		SUM(CASE WHEN mto_base IS NULL OR mto_base=0 THEN mto_impuesto/B.ITF ELSE mto_base END) AS MTO_BASE, 
		SUM(mto_impuesto) AS MTO_IMP
		INTO DB_PROC_CDP.DBO.AND_INF_ITF
		FROM DB_PROCESADO.DBO.TBL_ITF_2014 A
		LEFT JOIN DB_PROCESADO.DBO.TBL_INCT_PERCO_ITF B
		ON A.periodo_operacion=B.periodo
		WHERE periodo_operacion>'201408'
		AND cic_declado IN (SELECT CIC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		GROUP BY cic_declado
		
		INSERT INTO DB_PROC_CDP.DBO.AND_INF_ITF
		SELECT cic_declado AS CIC, SUM(CASE WHEN mto_base IS NULL OR mto_base=0 THEN mto_impuesto/B.ITF ELSE mto_base END) AS MTO_BASE, SUM(mto_impuesto) AS MTO_IMP
		FROM DB_PROCESADO.DBO.TBL_ITF_2015 A
		LEFT JOIN DB_PROCESADO.DBO.TBL_INCT_PERCO_ITF B
		ON A.periodo_operacion=B.periodo
		WHERE periodo_operacion>'201408'
		AND cic_declado IN (SELECT CIC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		GROUP BY cic_declado

		INSERT INTO DB_PROC_CDP.DBO.AND_INF_ITF
		SELECT cic_declado AS CIC, SUM(CASE WHEN mto_base IS NULL OR mto_base=0 THEN mto_impuesto/B.ITF ELSE mto_base END) AS MTO_BASE, SUM(mto_impuesto) AS MTO_IMP
		FROM DB_PROCESADO.DBO.TBL_ITF_2016 A
		LEFT JOIN DB_PROCESADO.DBO.TBL_INCT_PERCO_ITF B
		ON A.periodo_operacion=B.periodo
		WHERE periodo_operacion>'201408'
		AND cic_declado IN (SELECT CIC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		GROUP BY cic_declado

	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_INF_ITF_0')
		BEGIN
			DROP TABLE DB_PROC_CDP.DBO.AND_INF_ITF_0
		END
	ELSE
		BEGIN
			SELECT CIC,
			SUM(CASE 
			WHEN ISNULL(MTO_BASE,0) > 0
			THEN 1 
			ELSE 0 END) AS IND_MTO
			INTO DB_PROC_CDP.DBO.AND_INF_ITF_0
			FROM DB_PROC_CDP.DBO.AND_INF_ITF
			GROUP BY CIC
		END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_INF_ITF_1')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_INF_ITF_1
	END
	ELSE
	BEGIN
		SELECT CIC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_ITF
		INTO DB_PROC_CDP.DBO.AND_INF_ITF_1
		FROM DB_PROC_CDP.DBO.AND_INF_ITF_0
		GROUP BY CIC
	END

PRINT ('/8 -----***************************DETRACCIONES******************************/')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_INFRO_ADQUIRIENTE')
	BEGIN	
		DROP TABLE DB_PROC_CDP.DBO.AND_INFRO_ADQUIRIENTE
	END
	ELSE 
	BEGIN
		SELECT num_doc_adq AS RUC
		INTO DB_PROC_CDP.DBO.AND_INFRO_ADQUIRIENTE
		FROM DB_PROCESADO.DBO.TBL_INCT_DETRAC_MAESTRO
		WHERE DATEDIFF(MONTH,  CONVERT(DATE,SUBSTRING(fec_pag,7,4)+'/'+SUBSTRING(fec_pag,1,2)+'/'+SUBSTRING(fec_pag,4,2) ), '13-12-2016')<=24
		AND num_doc_adq IN (SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		GROUP BY num_doc_adq	
	END
	
	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_INFRO_PROVEEDOR')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_INFRO_PROVEEDOR
	END
	ELSE
	BEGIN
		SELECT num_ruc_prov AS RUC
		INTO DB_PROC_CDP.DBO.AND_INFRO_PROVEEDOR
		FROM DB_PROCESADO.DBO.TBL_INCT_DETRAC_MAESTRO
		WHERE DATEDIFF(MONTH,  CONVERT(DATE,SUBSTRING(fec_pag,7,4)+'/'+SUBSTRING(fec_pag,1,2)+'/'+SUBSTRING(fec_pag,4,2) ), '13-12-2016')<=24
		AND num_ruc_prov IN (SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
		GROUP BY num_ruc_prov
	END

PRINT ('/***************************1666******************************/')
PRINT ('--9 �	Formulario Virtual de Ganancias de Capital y Otras Rentas N� 1666')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_CASILLA_1666')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_CASILLA_1666
	END
	BEGIN
		SELECT cod_casilla AS CASILLA INTO DB_PROC_CDP.DBO.AND_CASILLA_1666
		FROM DB_PROC_CDP.DBO.d2784dimnem_NO_ELIMINAR A
		INNER JOIN DB_PROC_CDP.DBO.p2813casilla_NO_ELIMINAR B
		ON A.cod_nemotec=B.cod_nemotec
		WHERE B.cod_formul='1666'
		AND B.ind_tipdato='N'
		AND SUBSTRING(B.cod_nemotec,1,3)='mto'
	END

	/*
	select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
	x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
	from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
	where (x0.cod_formul = "1666" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
	AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
	AND x1.cod_casilla IN ("326","329","336","338","347","349","369","389","399","500","501","502","503","504","505","506","507","516","517","518","519","550","551","552","553","554","555","599"))
	AND cod_veredito NOT IN ("2","4")
	--168 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_1666.TXT (3836.64 secs)

	DROP TABLE DB_PROC_CDP.DBO.AND_DET_1666
	SELECT 
	TOP 0 *
	INTO DB_PROC_CDP.DBO.AND_DET_1666
	FROM OPENQUERY(DEANDRE,
	'select FIRST 1 x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
	x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
	from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
	where (x0.cod_formul = "1666" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
	AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
	AND x1.cod_casilla IN ("326","329","336","338","347","349","369","389","399","500","501","502","503","504","505","506","507","516","517","518","519","550","551","552","553","554","555","599"))
	AND cod_veredito NOT IN ("2","4")
	')
	*/
	TRUNCATE TABLE DB_PROC_CDP.DBO.AND_DET_1666
	INSERT INTO DB_PROC_CDP.DBO.AND_DET_1666
	SELECT 	*	FROM OPENQUERY(DEANDRE,
	'select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,
	x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
	x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
	from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
	where (x0.cod_formul = "1666" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
	AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
	AND x1.cod_casilla IN ("326","329","336","338","347","349","369","389","399","500","501","502","503",
	"504","505","506","507","516","517","518","519","550","551","552","553","554","555","599"))
	AND cod_veredito NOT IN ("2","4")
	')
	--SQL executed OK. Number of rows affected=0 (0.68 secs)
	--(84 row(s) affected)

	IF EXISTS( SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_1666_0')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_1666_0
	END
	ELSE
	BEGIN
		SELECT n_doc_declado AS RUC,
		SUM(CASE 
		WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
		THEN 1 
		ELSE 0 END) AS IND_MTO
		INTO DB_PROC_CDP.DBO.AND_DET_1666_0
		FROM DB_PROC_CDP.DBO.AND_DET_1666
		WHERE CASILLA IN (SELECT CASILLA FROM DB_PROC_CDP.DBO.AND_CASILLA_1666)
		AND PERIODO BETWEEN '201401' AND '201612'
		AND DATEDIFF(MONTH,  f_presenta, '13-12-2016')<=24
		GROUP BY n_doc_declado
	END

	IF EXISTS( SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_1666_1')
	BEGIN
	 DROP TABLE DB_PROC_CDP.DBO.AND_DET_1666_1
	END	
	ELSE
	BEGIN
	    SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_1666
		INTO DB_PROC_CDP.DBO.AND_DET_1666_1
		FROM DB_PROC_CDP.DBO.AND_DET_1666_0
		GROUP BY RUC
	END
	

PRINT ('/*********************************************** CAVALI ********************************************/')
PRINT ('-----------------------------------------------------------------------------------------------------'
PRINT ('--10 �	Con informaci�n de retenci�n de rentas de 2da (ganancias de K informados por CAVALI)---------').

	/*
	Select * from informix.vw_cab_unicas
	where formulario IN ('1666','0617') and periodo between '201401' and '201612'
	--1520907 rows of data written to d:\Users\asanchezb\Desktop\vw_cab_unicas_1666_0617.TXT (180.46 secs)
	*/

	DROP TABLE DB_PROC_CDP.DBO.vw_cab_unicas_0617_1666
	SELECT TOP 0 *
	INTO DB_PROC_CDP.DBO.vw_cab_unicas_0617_1666
	FROM OPENQUERY(DEANDRE,
	'Select FIRST 1 * from informix.vw_cab_unicas'
	)

	/*
	Select * from informix.vw_otrasret
	where periodo between '201401' and '201612'
	--5162279 rows of data written to d:\Users\asanchezb\Desktop\vw_otrasret.TXT (1098.66 secs)
	*/

	DROP TABLE DB_PROC_CDP.DBO.vw_otrasret
	SELECT TOP 0 * 	INTO DB_PROC_CDP.DBO.vw_otrasret
	FROM OPENQUERY(DEANDRE,
	'Select FIRST 1 * from informix.vw_otrasret'
	)

	IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_2DA_OTRA' )
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_2DA_OTRA
	END
	ELSE
	BEGIN
		SELECT A.*
		INTO DB_PROC_CDP.DBO.AND_DET_2DA_OTRA
		FROM DB_PROC_CDP.DBO.vw_otrasret A
		INNER JOIN DB_PROC_CDP.DBO.vw_cab_unicas_0617_1666 B
		ON A.nota_abono=B.nabono
		AND A.formulario=B.formulario
		AND A.n_orden=B.nro_orden
		AND B.tributo='030202'
	END

	IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_2DA_OTRA_0' ) 
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_2DA_OTRA_0
	END
	BEGIN
		SELECT DISTINCT 
		periodo, formulario,cic_decpdt, tipo_dcto_decpdt, nro_dcto_decpdt, nro_dcto_ret,  tipo_dcto_ret, 0 AS CIC,
		(CASE
		WHEN caracter_renta='01' THEN caracter_renta+' - Renta gravada'
		WHEN caracter_renta='02' THEN caracter_renta+' - Renta Exonerada'
		WHEN caracter_renta='03' THEN caracter_renta+' - Renta Inafecta'
		END) AS caracter_renta, 

		(CASE
		WHEN tipo_renta='0' THEN  tipo_renta+ ' - NO APLICA'
		WHEN tipo_renta='1' THEN  tipo_renta+ ' - Art 72'
		WHEN tipo_renta='2' THEN  tipo_renta+ ' - Art 73'
		WHEN tipo_renta='3' THEN  tipo_renta+ ' - Art 77 A inc A. LIR'
		WHEN tipo_renta='4' THEN  tipo_renta+ ' - Art 77 A penultimo parr LIR'
		WHEN tipo_renta='5' THEN  tipo_renta+ ' - Art 72 seg parr LIB'
		WHEN tipo_renta='6' THEN  tipo_renta+ ' - Enajenaci�n de Valores mobiliarios'
		WHEN tipo_renta='7' THEN  tipo_renta+ ' - Intereses'
		END) AS tipo_renta
		INTO DB_PROC_CDP.DBO.AND_DET_2DA_OTRA_0 
		FROM DB_PROC_CDP.DBO.AND_DET_2DA_OTRA 
		WHERE tipo_retencion='1'
		AND PERIODO>'201408'
		AND cic_decpdt=15258406

		UPDATE A
		SET CIC=B.CIC
		FROM DB_PROC_CDP.DBO.AND_DET_2DA_OTRA_0 A
		INNER JOIN DB_PADRON.DBO.TBL_GPGF_IDENTIFICADOS B
		ON A.tipo_dcto_ret=B.TIPO_DCTO_DECLADO
		AND A.nro_dcto_ret=B.N_DCTO_DECLADO COLLATE SQL_Latin1_General_CP1_CI_AS
	END

	IF EXISTS(SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_2DA_OTRA_1')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_2DA_OTRA_1
	END
	ELSE
	BEGIN
		SELECT CIC
		INTO DB_PROC_CDP.DBO.AND_DET_2DA_OTRA_1
		FROM DB_PROC_CDP.DBO.AND_DET_2DA_OTRA_0
		WHERE tipo_renta = '6 - Enajenaci�n de Valores mobiliarios'
		GROUP BY CIC
	END

PRINT('/*************************** PDT NOTARIO ******************************/')
PRINT('------------------------------------------------------------------------')
PRINT('-----11 �	Con informaci�n en PDT Notarios.   ')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_NOT_OTRA_0')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_NOT_OTRA_0
	END
	ELSE
	BEGIN
		SELECT cod_tipdocoto, num_docoto, CONVERT(INT, 0) AS CIC
		INTO DB_PROC_CDP.DBO.AND_DET_NOT_OTRA_0
		FROM DB_PROCESADO.DBO.TBL_INCT_NOTARIOS_2014
		WHERE DATEDIFF(MONTH, fec_numesc, '13-12-2016')<=24
		AND mto_actjur>0
		GROUP BY cod_tipdocoto, num_docoto

		INSERT INTO DB_PROC_CDP.DBO.AND_DET_NOT_OTRA_0
		SELECT cod_tipdocoto, num_docoto, CONVERT(INT, 0) AS CIC
		FROM DB_PROCESADO.DBO.TBL_INCT_NOTARIOS_2015
		WHERE DATEDIFF(MONTH, fec_numesc, '13-12-2016')<=24
		AND mto_actjur>0
		GROUP BY cod_tipdocoto, num_docoto

		UPDATE A
		SET CIC=B.CIC
		FROM DB_PROC_CDP.DBO.AND_DET_NOT_OTRA_0 A
		INNER JOIN DB_PADRON.DBO.TBL_GPGF_IDENTIFICADOS B
		ON A.cod_tipdocoto=B.TIPO_DCTO_DECLADO
		AND A.num_docoto=B.N_DCTO_DECLADO COLLATE SQL_Latin1_General_CP1_CI_AS
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DET_NOT_OTRA_1')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DET_NOT_OTRA_1
	END
	ELSE
	BEGIN
		SELECT CIC
		INTO DB_PROC_CDP.DBO.AND_DET_NOT_OTRA_1
		FROM DB_PROC_CDP.DBO.AND_DET_NOT_OTRA_0
		GROUP BY CIC
	END

PRINT ('/************************************************************************************************************/')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DDJJ_TODO_MAY_MTO_1')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DDJJ_TODO_MAY_MTO_1
	END
	ELSE
	BEGIN
		SELECT A.RUC 
		INTO DB_PROC_CDP.DBO.AND_DDJJ_TODO_MAY_MTO_1
		FROM 
		(
		SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_PROC_CDP.DBO.AND_DET_0621_1  WHERE IND_MTO_0621=1--OK
		UNION ALL
		SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_PROC_CDP.DBO.AND_DET_0626_1  WHERE IND_MTO_0626=1--OK
		UNION ALL
		SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_PROC_CDP.DBO.AND_DET_0633_1  WHERE IND_MTO_0633=1--OK
		UNION ALL
		SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_PROC_CDP.DBO.AND_DET_0697_1  WHERE IND_MTO_0697=1--OK
		UNION ALL
		SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_PROC_CDP.DBO.AND_DET_RT_PJ_1 WHERE IND_MTO_RTA_PJ=1 --OK
		UNION ALL
		SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_PROC_CDP.DBO.AND_DET_RT_PN_1 WHERE IND_MTO_RTA_PN=1 --OK
		UNION ALL
		SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_PROC_CDP.DBO.AND_DET_1666_1  WHERE IND_MTO_1666=1 --OK
		UNION ALL
		SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_PROC_CDP.DBO.AND_INFRO_ADQUIRIENTE --OK
		UNION ALL
		SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_PROC_CDP.DBO.AND_INFRO_PROVEEDOR --OK
		) A
		GROUP BY A.RUC
	END

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='AND_DDJJ_TODO_MAY_MTO_2')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_DDJJ_TODO_MAY_MTO_2
	END
	ELSE
	BEGIN
		SELECT CIC
		INTO DB_PROC_CDP.DBO.AND_DDJJ_TODO_MAY_MTO_2
		FROM
		(
			SELECT CIC FROM DB_PROC_CDP.DBO.AND_INF_ITF_1 
			UNION ALL
			SELECT CIC FROM DB_PROC_CDP.DBO.AND_DET_2DA_OTRA_1 
			UNION ALL
			SELECT CIC FROM DB_PROC_CDP.DBO.AND_DET_NOT_OTRA_1
		) A
		GROUP BY CIC
		-----------------------------------------------------------------------------------------
		UPDATE A
		SET TIP_EXC_2_I_7='X'
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
		INNER JOIN DB_PROC_CDP.DBO.AND_DDJJ_TODO_MAY_MTO_1  B
		ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS

		------------------------------------------------------------------------------------------
		UPDATE A
		SET TIP_EXC_2_I_7='X'
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
		INNER JOIN DB_PROC_CDP.DBO.AND_DDJJ_TODO_MAY_MTO_2  B
		ON A.CIC=B.CIC
		AND A.CIC<>0
	END





------------------------------------------------------------------------------------------------------------------------------------
--I - A - 8

IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='TBL_Solicitudes_Devolucion')
BEGIN
	DROP TABLE DB_PROC_CDP.DBO.TBL_Solicitudes_Devolucion
END
ELSE
BEGIN
	SELECT *
	INTO DB_PROC_CDP.DBO.TBL_Solicitudes_Devolucion
	FROM DB_GPGD.DBO.TBL_Solicitudes_Devolucion
	WHERE A�O=@A�O AND MES=@MES
	AND RUC IN (SELECT RUC FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
END


IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='TBL_Solicitudes_Devolucion_1')
BEGIN
	DROP TABLE DB_PROC_CDP.DBO.TBL_Solicitudes_Devolucion_1
END
ELSE
BEGIN
	SELECT RUC
	INTO DB_PROC_CDP.DBO.TBL_Solicitudes_Devolucion_1
	FROM DB_PROC_CDP.DBO.TBL_Solicitudes_Devolucion
	WHERE DATEDIFF(MONTH,  fec_doc, '13-12-2016')<=24 AND cod_tip_sol='02'
	GROUP BY RUC

	UPDATE A
	SET TIP_EXC_2_I_8='X'
	FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
	INNER JOIN DB_PROC_CDP.DBO.TBL_Solicitudes_Devolucion_1  B
	ON A.RUC=B.RUC
	AND A.CIC<>0
END


PRINT ('/****************************************************************************************************/')
PRINT ('---------------------------EXCLUSIONES DEUDORES PROCESOS CENTRALIZADOS--------------------------------')
PRINT ('/****************************************************************************************************/')

PRINT ('---------------------------------NO SE HA PROCESADO NO HAY DATA-------------------------------------')
PRINT ('----------------------------------------------------------------------------------------------------')


PRINT ('--II - A  --2� Estado Activo')

	UPDATE A
	SET TIP_EXC_2_II_A='X'
	FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
	INNER JOIN DB_DATA_WH.PADRON.TB_CONTRIBUYENTE  B
	ON A.RUC=B.num_ruc 
	WHERE B.id_estcontri=0

------------------------------------------------------------------------------------------------------------------------------------ 
PRINT ('--II - B --3� Condici�n de Domicilio: Habido')
	
	UPDATE A
	SET TIP_EXC_2_II_B='X'
	FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
	INNER JOIN DB_DATA_WH.PADRON.TB_CONTRIBUYENTE  B
	ON A.RUC=B.num_ruc 
	WHERE B.id_conddom=0

-------------------------------------------------------------------------------------------------------------------------------------
PRINT ('--II - C --1� Que tengan perfil de comportamiento Cumplidor, Inducible o Mixto.')

	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1 AND NAME='tbl_Padron_segmento_pago')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.tbl_Padron_segmento_pago
	END
	ELSE
	BEGIN
		SELECT NUM_RUC AS RUC,id_subsegpago, CONVERT(INT,NULL) AS id_perfil 
		INTO DB_PROC_CDP.DBO.tbl_Padron_segmento_pago
		FROM DB_DATA_WH.PADRON.TB_SEGMENTO_PAGO_HIST WITH (NOLOCK)
		WHERE YEAR(FEC_FINVIG)=2100

		UPDATE A
		SET id_perfil=C.id_perfilpago
		FROM DB_PROC_CDP.DBO.tbl_Padron_segmento_pago A WITH (NOLOCK)
		INNER JOIN DB_DATA_WH.PADRON.TB_SUBSEGPAGO B WITH (NOLOCK)
		ON A.id_subsegpago=B.id_subsegpago 
		INNER JOIN DB_DATA_WH.PADRON.TB_SEGPAGO C WITH (NOLOCK)
		ON B.id_segpago=C.id_segpago 

		UPDATE A
		SET TIP_EXC_2_II_C='X'
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
		INNER JOIN DB_PROC_CDP.DBO.tbl_Padron_segmento_pago  B
		ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS
		WHERE id_perfil IN (4,5,0)
	END

PRINT ('------------------------------------------------------------------------------------------------------------------------------')
PRINT ('--II - D --1� Que tengan bienes registrados en SUNARP (En caso PPNN cruce masivo por DNI y/o Apellidos y Nombres y en PPJJ cruce masivo por identidad de Raz�n Social). ')

	
	IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1  AND NAME='AND_INFR_SUNARP')

	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_INFR_SUNARP
	END
	ELSE
	BEGIN
		SELECT COD_CIC AS CIC
		INTO DB_PROC_CDP.DBO.AND_INFR_SUNARP
		FROM
		(
			SELECT COD_CIC FROM DB_PROC_CDP.DBO.AND_SUNARP_BUQUE WHERE COD_CIC<>0 AND nom_partic='PROPIETARIO' AND ind_estado=1 
			UNION ALL
			SELECT COD_CIC FROM DB_PROC_CDP.DBO.AND_SUNARP_EMBAR WHERE COD_CIC<>0 AND nom_partic='PROPIETARIO' AND ind_estado=1
			UNION ALL
			SELECT COD_CIC FROM DB_PROC_CDP.DBO.AND_SUNARP_AERO WHERE COD_CIC<>0 AND nom_partic='PROPIETARIO' AND ind_estado=1
			UNION ALL
			SELECT COD_CIC FROM DB_PROC_CDP.DBO.AND_SUNARP_PRED WHERE COD_CIC<>0 AND nom_partic='PROPIETARIO' AND ind_estado=1
			UNION ALL
			SELECT COD_CIC FROM DB_PROC_CDP.DBO.AND_SUNARP_VEHI WHERE COD_CIC<>0 AND nom_partic='TITULAR' AND ind_estado=1
		) A
		GROUP BY COD_CIC
		
		UPDATE A
		SET TIP_EXC_2_II_D='X'
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
		INNER JOIN DB_PROC_CDP.DBO.AND_INFR_SUNARP  B
		ON A.CIC=B.CIC
		AND A.CIC<>0
	END

/***********************************************************************************************/
IF EXISTS (SELECT * FROM SYS.OBJECTS WHERE [TYPE]='U' AND SCHEMA_ID=1  AND NAME='AND_SALDOS_VALORES_PENDIENTES_6')
	BEGIN
		DROP TABLE DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_6
	END
	ELSE
	BEGIN
		SELECT *
		INTO DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_6
		FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2
		WHERE TIP_EXC_2_A<>'X' 
				AND TIP_EXC_2_B<>'X' 
				AND TIP_EXC_2_C<>'X' 
				AND TIP_EXC_2_I_1<>'X' 
				AND TIP_EXC_2_I_2<>'X' 
				AND TIP_EXC_2_I_3<>'X' 
				AND TIP_EXC_2_I_4<>'X' 
				AND TIP_EXC_2_I_5<>'X' 
				AND TIP_EXC_2_I_6<>'X' 
				AND TIP_EXC_2_I_7<>'X' 
				AND TIP_EXC_2_II_A<>'X' 
				AND TIP_EXC_2_II_B<>'X' 
				AND TIP_EXC_2_II_C<>'X' 
				AND TIP_EXC_2_II_D<>'X'
	END

CREATE INDEX IND_RUC ON DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_6 (RUC)
CREATE INDEX IND_RUC ON DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_2 (RUC)



DROP TABLE DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_4
SELECT RUC,
COUNT(*) AS CNT_VALORES,
SUM(mto_trib+mto_int+mto_cap+mto_rec) AS MTO_INSOLUTO,
SUM(trib_exig+int_exig+cap_exig+rec_exig) AS MTO_SALDO_EXIGIBLE,
SUM(sal_trib+sal_int+sal_cap+sal_rec) AS MTO_SALDO_TOTAL
INTO DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_4
FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_1
GROUP BY RUC
--(362767 row(s) affected)
--SQL executed OK. Number of rows affected=202584 (3.37 secs)

CREATE INDEX IND_RUC ON DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_4 (RUC)
--OK

DROP TABLE DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_3
SELECT 
		D.cod_depen,
		D.nom_depen,
		A.RUC,
		replace(B.NOM_RAZSOC,'"','') AS NOM_RAZSOC,
		C.des_conddom,
		E.des_estcontri,
		T.des_tipocontri,
		PP.des_perfilpago,
		SF.nom_segfisca,
		AA.CNT_VALORES,
		AA.MTO_INSOLUTO,
		AA.MTO_SALDO_EXIGIBLE,
		AA.MTO_SALDO_TOTAL
INTO DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_3
FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_6 A
INNER JOIN DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_4 AA	ON AA.RUC=A.RUC
LEFT JOIN DB_DATA_WH.PADRON.TB_CONTRIBUYENTE B					ON A.RUC=B.NUM_RUC
LEFT JOIN DB_DATA_WH.PADRON.TB_DEPENDENCIA D					ON B.ID_DEPEN=D.ID_DEPEN
LEFT JOIN DB_DATA_WH.PADRON.TB_CONDI_DOMIC_CONTRI C				ON B.ID_CONDDOM=C.ID_CONDDOM
LEFT JOIN DB_DATA_WH.PADRON.TB_ESTADO_CONTRIBUYENTE E			ON B.ID_ESTCONTRI=E.ID_ESTCONTRI
LEFT JOIN DB_DATA_WH.PADRON.TB_TIPO_CONTRIBUYENTE T				ON B.ID_TIPCONTRI=T.ID_TIPCONTRI
LEFT JOIN DB_DATA_WH.PADRON.TB_SUBSEGPAGO SSP					ON B.ID_SUBSEGPAGO=SSP.ID_SUBSEGPAGO
LEFT JOIN DB_DATA_WH.PADRON.TB_SEGPAGO SP						ON SSP.ID_SEGPAGO=SP.ID_SEGPAGO
LEFT JOIN DB_DATA_WH.PADRON.TB_PERFIL_PAGO PP					ON SP.ID_PERFILPAGO=PP.ID_PERFILPAGO
LEFT JOIN DB_DATA_WH.PADRON.TB_SEGMENTOFISCA SF					ON B.ID_SEGFISCA=SF.ID_SEGFISCA


CREATE INDEX IND_RUC ON DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_3 (RUC)

DROP TABLE DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
SELECT
A.RUC,
replace(B.NOM_RAZSOC,'"','') AS NOM_RAZSOC,
A.cod_valor,  A.tipo_doc,  year(A.fec_coa)*100+month(A.fec_coa) as periodo,  A.cod_trib,  
(A.mto_trib+A.mto_int+A.mto_cap+A.mto_rec) AS MTO_INSOLUTO,  
(A.trib_exig+A.int_exig+A.cap_exig+A.rec_exig) AS MTO_SALDO_EXIGIBLE,
(A.sal_trib+A.sal_int+A.sal_cap+A.sal_rec) AS MTO_SALDO_TOTAL,
ROW_NUMBER() OVER (ORDER BY A.RUC DESC) AS ord
INTO DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_1 A
INNER JOIN DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_3 B
ON A.RUC=B.RUC

SELECT RUC, NOM_RAZSOC, cod_valor, tipo_doc, periodo, cod_trib, MTO_INSOLUTO, MTO_SALDO_EXIGIBLE, MTO_SALDO_TOTAL
FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
WHERE ORD<=500000

SELECT RUC, NOM_RAZSOC, cod_valor, tipo_doc, periodo, cod_trib, MTO_INSOLUTO, MTO_SALDO_EXIGIBLE, MTO_SALDO_TOTAL
FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
WHERE ORD>500000 AND ORD<=1000000

SELECT RUC, NOM_RAZSOC, cod_valor, tipo_doc, periodo, cod_trib, MTO_INSOLUTO, MTO_SALDO_EXIGIBLE, MTO_SALDO_TOTAL
FROM DB_PROC_CDP.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
WHERE ORD>1000000 


SELECT MAX(MES)
FROM DB_GPGD.DBO.TBR_Saldos_Valores_Pendientes
WHERE A�O=2016
AND MES='09'

DROP TABLE DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES
SELECT *
INTO DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES
FROM DB_GPGD.DBO.TBR_Saldos_Valores_Pendientes
WHERE A�O=2016
AND MES='09'
--SQL executed OK. Number of rows affected=4985036 (55.74 secs)
--SQL executed OK. Number of rows affected=4969016 (306.56 secs)

/****************************************************************************************************/
---EXCLUSIONES
/****************************************************************************************************/

DROP TABLE DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_0
SELECT *
INTO DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_0
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES WITH (NOLOCK)
WHERE 
DATEDIFF(MONTH, fec_coa, '22-09-2016')>48
AND (sal_trib+sal_int+sal_cap+sal_rec)>0
AND etapa_bas='03'
AND cod_doc IN
(
SELECT DISTINCT cod_doc
FROM DB_GPGD.DBO.Param_Tipo_DOC WITH (NOLOCK)
WHERE tipo IN ('OP', 'RD', 'RM', 'RIP')
)
--SQL executed OK. Number of rows affected=4765407 (36.97 secs)
--SQL executed OK. Number of rows affected=4265662 (42.21 secs)
--SQL executed OK. Number of rows affected=1522682 (36.21 secs)
--SQL executed OK. Number of rows affected=1509896 (22.53 secs)

--SQL executed OK. Number of rows affected=363851 (1.03 secs)
--SQL executed OK. Number of rows affected=1510278 (20.94 secs)
--SQL executed OK. Number of rows affected=2768906 (30.86 secs)

--DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_0_back

DROP TABLE DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_1
SELECT *
INTO DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_1
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_0  WITH (NOLOCK)
--WHERE fallecido='N'
/*AND cod_trib NOT IN 
(
'052000','052100','052101','052102','052103','052104','052105','052106','052107','052108','052109','052200','052201','052202','052203','052204',
'052205','052206','052207','052208','052209','052300','052301','052302','052303','052304','052305','052306','052307','052308','052309','052402',
'052404','053100','053102','053103','053104','053105','053106','053107','053109','053200','053201','053202','053203','053204','053206','053207',
'053208','053209','053300','053301','053302','053303','053305','053401','053402','054100','054101','054102','055100','055101','055102','056102',
'056201','056204','056301','056302','056402','064101','064102','064104','064106','064107','064301','064304','064305','064306','064307','064401',
'064501','064601','064604','064701','064702','064703','064704','064705','064706','064708','064801','064803','064804','064805','064806','064807',
'064809','064901','065003','065201','065301','065302','065303','065305','066305','066306','066307','066308','080403','080702'
)*/
--AND cod_doc NOT IN ('102000','112000','102001')
--SQL executed OK. Number of rows affected=1513124 (7.21 secs)
--SQL executed OK. Number of rows affected=881658 (11.11 secs)
--SQL executed OK. Number of rows affected=1509896 (16.52 secs)
--SQL executed OK. Number of rows affected=1510278 (7.69 secs)
--SQL executed OK. Number of rows affected=2768906 (21.04 secs)

DROP TABLE DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2
SELECT CIC, RUC, SUM(sal_trib+sal_int+sal_cap+sal_rec) AS DEUDA,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_A,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_B,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_C,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_1,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_2,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_3,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_4,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_5,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_6,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_7,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_I_8,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_II_A,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_II_B,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_II_C,
CONVERT(VARCHAR(1),'') AS TIP_EXC_2_II_D
INTO DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_1 WITH (NOLOCK)
GROUP BY CIC, RUC
--SQL executed OK. Number of rows affected=361615 (4.18 secs)
--SQL executed OK. Number of rows affected=361619 (1.30 secs)
--SQL executed OK. Number of rows affected=316563 (1.03 secs)
--SQL executed OK. Number of rows affected=362767 (4.12 secs)
--SQL executed OK. Number of rows affected=362840 (1.42 secs)
--SQL executed OK. Number of rows affected=202584 (1.81 secs)

--EXPORTAR
SELECT CIC
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_0_back A
WHERE CIC NOT IN 
	(
	SELECT CIC
	FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_0
	GROUP BY CIC
	) 
GROUP BY CIC


SELECT CIC
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2
GROUP BY CIC

/****************************************************************************************************/
---EXCLUSIONES DEUDORES 
/****************************************************************************************************/

------------------------------------------------------------------------------------------------------------------------------------
--A
--2� Que est� en Procedimiento Concursal o Reorganizaci�n de sociedades. 

DROP TABLE DB_NQ77.DBO.AND_INF_PC
SELECT RUC
INTO DB_NQ77.DBO.AND_INF_PC
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES
WHERE etapa_alt='15'
GROUP BY RUC
--SQL executed OK. Number of rows affected=1245 (0.36 secs)


UPDATE A
SET TIP_EXC_2_A='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.AND_INF_PC  B
ON A.RUC=B.RUC
--SQL executed OK. Number of rows affected=193 (0.08 secs)
--SQL executed OK. Number of rows affected=194 (2.76 secs)
--SQL executed OK. Number of rows affected=995 (7.55 secs)

------------------------------------------------------------------------------------------------------------------------------------
--B
--2� Que est� en Procedimiento de Reorganizaci�n de sociedades. 

------------------------------------------------------------------------------------------------------------------------------------
--C
--3� Que tenga una RD de atribuci�n de responsabilidad solidaria activa

DROP TABLE DB_NQ77.DBO.AND_INF_RD
SELECT RUC
INTO DB_NQ77.DBO.AND_INF_RD
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES
WHERE cod_doc IN ('004000','004020','004010')
GROUP BY RUC
--SQL executed OK. Number of rows affected=0 (1.32 secs)

UPDATE A
SET TIP_EXC_2_C='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.AND_INF_RD  B
ON A.RUC=B.RUC
--SQL executed OK. Number of rows affected=0 (0.08 secs)



/****************************************************************************************************/
--EXCLUSIONES DEUDORES PROCESOS DESCENTRALIZADOS - movimiento en 24 meses '22-09-2016'
/****************************************************************************************************/
------------------------------------------------------------------------------------------------------------------------------------
--I - A - 1
--1� Que tenga o haya tenido valores emitidos (en cualquier estado) 
DROP TABLE DB_NQ77.DBO.TBL_Valores_Emitidos_0
SELECT RUC 
INTO DB_NQ77.DBO.TBL_Valores_Emitidos_0
FROM DB_GPGD.DBO.TBL_Valores_Emitidos
WHERE DATEDIFF(MONTH,  fec_emi, '22-09-2016')<=24
GROUP BY RUC
--SQL executed OK. Number of rows affected=704274 (11.79 secs)

UPDATE A
SET TIP_EXC_2_I_1='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.TBL_Valores_Emitidos_0  B
ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS
--SQL executed OK. Number of rows affected=221766 (8.52 secs)
--SQL executed OK. Number of rows affected=221770 (8.89 secs)
--SQL executed OK. Number of rows affected=17676 (1.91 secs)

------------------------------------------------------------------------------------------------------------------------------------
--I - A - 2
--no hay
DROP TABLE DB_NQ77.DBO.AND_PAGOS_MULTA
SELECT * 
INTO DB_NQ77.DBO.AND_PAGOS_MULTA
FROM DB_TERADATA.DBO.vw_pagos_per2014
WHERE CIC IN (SELECT CIC FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 WHERE CIC<>0)
--SQL executed OK. Number of rows affected=1394518 (65.30 secs)
INSERT INTO DB_NQ77.DBO.AND_PAGOS_MULTA
SELECT * 
FROM DB_TERADATA.DBO.vw_pagos_per2015
WHERE CIC IN (SELECT CIC FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 WHERE CIC<>0)
--OK
INSERT INTO DB_NQ77.DBO.AND_PAGOS_MULTA
SELECT * 
FROM DB_TERADATA.DBO.vw_pagos_per2016
WHERE CIC IN (SELECT CIC FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 WHERE CIC<>0)
--SQL executed OK. Number of rows affected=313734 (4.65 secs)
--SQL executed OK. Number of rows affected=5330002 (167.72 secs)
--SQL executed OK. Number of rows affected=5330258 (206.68 secs)

DROP TABLE DB_NQ77.DBO.AND_PAGOS_MULTA_0
SELECT num_doc AS RUC
INTO DB_NQ77.DBO.AND_PAGOS_MULTA_0
FROM DB_NQ77.DBO.AND_PAGOS_MULTA
WHERE DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
AND num_doc IN (SELECT RUC FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
AND valor_casilla>0
GROUP BY num_doc
--SQL executed OK. Number of rows affected=78077 (1.46 secs)
--SQL executed OK. Number of rows affected=179029 (4.37 secs)
--SQL executed OK. Number of rows affected=179038 (8.59 secs)

UPDATE A
SET TIP_EXC_2_I_2='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.AND_PAGOS_MULTA_0  B
ON A.RUC=B.RUC
--SQL executed OK. Number of rows affected=179029 (10.58 secs)
--SQL executed OK. Number of rows affected=179038 (8.71 secs)
--SQL executed OK. Number of rows affected=12270 (2.05 secs)
------------------------------------------------------------------------------------------------------------------------------------
--I - A - 3
--
DROP TABLE DB_NQ77.DBO.gpgd_solic_fracc_resueltas_0
SELECT RUC 
INTO DB_NQ77.DBO.gpgd_solic_fracc_resueltas_0
FROM DB_GPGD.DBO.gpgd_solic_fracc_resueltas
WHERE DATEDIFF(MONTH,  fec_rin, '22-09-2016')<=24
AND cod_doc IN ('017117','017701','017500','017001')
GROUP BY RUC
--SQL executed OK. Number of rows affected=208181 (4.21 secs) 

UPDATE A
SET TIP_EXC_2_I_3='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.gpgd_solic_fracc_resueltas_0  B
ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS
--SQL executed OK. Number of rows affected=38672 (4.03 secs)
--SQL executed OK. Number of rows affected=1149 (1.48 secs)

------------------------------------------------------------------------------------------------------------------------------------
--I - A - 4
--NO HAY


------------------------------------------------------------------------------------------------------------------------------------
--I - A - 5
--4� Que hayan obtenido autorizaci�n de impresi�n CdP 
DROP TABLE DB_NQ77.DBO.AND_AUTORIZA_CPE
SELECT RUC 
INTO DB_NQ77.DBO.AND_AUTORIZA_CPE
FROM DB_PADRON.DBO.Tbl_gpgf_autorizacion_cdp
WHERE DATEDIFF(MONTH,fec_autoriz, '22-09-2016')<=24
GROUP BY RUC
--SQL executed OK. Number of rows affected=1557733 (6.73 secs)
--SQL executed OK. Number of rows affected=1459494 (8.07 secs)

UPDATE A
SET TIP_EXC_2_I_5='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.AND_AUTORIZA_CPE  B
ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS
--SQL executed OK. Number of rows affected=115551 (5.05 secs)
--SQL executed OK. Number of rows affected=127787 (4.03 secs)
--SQL executed OK. Number of rows affected=123501 (6.58 secs)
--SQL executed OK. Number of rows affected=123507 (7.00 secs)
--SQL executed OK. Number of rows affected=4743 (3.08 secs)

------------------------------------------------------------------------------------------------------------------------------------
--I - A - 6
--4� Que hayan emitido Comprobante de Pago Electr�nico

/*
select 
x0.cod_tipocomp ,x0.num_ruc ,
x0.num_seriecpe ,x0.num_cpe ,
x0.cod_moneda ,x0.num_establec ,x0.cod_cic ,x0.num_docidenti ,x0.cod_tipidenti ,
x0.cod_tipocpe ,x0.fec_emicpe 
from sif:"admdwh".t5938cabcpe X0
--82025324 rows of data written to d:\Users\asanchezb\Desktop\t5938cabcpe_RESUMEN_TODO.TXT (6887.29 secs)
--159404071 rows of data written to d:\Users\asanchezb\Desktop\t5938cabcpe.TXT (14448.43 secs)
*/

DROP TABLE DB_NQ77.DBO.t5938cabcpe
SELECT TOP 0
*
INTO DB_NQ77.DBO.t5938cabcpe
FROM OPENQUERY(DEANDRE,
'
select FIRST 1
x0.cod_tipocomp ,x0.num_ruc ,
x0.num_seriecpe ,x0.num_cpe ,
x0.cod_moneda ,x0.num_establec ,x0.cod_cic ,x0.num_docidenti ,x0.cod_tipidenti ,
x0.cod_tipocpe ,x0.fec_emicpe 
from sif:"admdwh".t5938cabcpe X0
')
--SQL executed OK. Number of rows affected=0 (0.86 secs)


DROP TABLE DB_NQ77.DBO.t5938cabcpe_0
SELECT num_ruc AS RUC
INTO DB_NQ77.DBO.t5938cabcpe_0
FROM DB_NQ77.DBO.t5938cabcpe
WHERE DATEDIFF(MONTH,  fec_emicpe, '22-09-2016')<=24
GROUP BY num_ruc
--SQL executed OK. Number of rows affected=55351 (9.16 secs)
--SQL executed OK. Number of rows affected=93983 (64.73 secs)

UPDATE A
SET TIP_EXC_2_I_6='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.t5938cabcpe_0  B
ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS
--SQL executed OK. Number of rows affected=9867 (2.68 secs)
--SQL executed OK. Number of rows affected=311 (2.81 secs)

------------------------------------------------------------------------------------------------------------------------------------
--I - A - 7

/***************************0621******************************/
--1 �	Declara F�cil - Formulario Virtual N� 621 IGV Renta Mensual 
DROP TABLE DB_NQ77.DBO.AND_CASILLA_0621
SELECT cod_casilla AS CASILLA
INTO DB_NQ77.DBO.AND_CASILLA_0621
FROM DB_NQ77.DBO.d2784dimnem_NO_ELIMINAR A
INNER JOIN DB_NQ77.DBO.p2813casilla_NO_ELIMINAR B
ON A.cod_nemotec=B.cod_nemotec
WHERE B.cod_formul='0621'
AND B.ind_tipdato='N'
AND SUBSTRING(B.cod_nemotec,1,3)='mto'
--SQL executed OK. Number of rows affected=198 (0.20 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_0621
SELECT *
INTO DB_NQ77.DBO.AND_DET_0621
FROM DB_TERADATA.DBO.POC_IGV_DET_F0621
WHERE n_doc_declado IN 
(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
AND PERIODO>='201401'
--SQL executed OK. Number of rows affected=234187904 (840.02 secs)
--SQL executed OK. Number of rows affected=273971233 (1037.93 secs)
--(27783944 row(s) affected)--13 MINT

DROP TABLE DB_NQ77.DBO.AND_DET_0621_0
SELECT n_doc_declado AS RUC,
SUM(CASE 
WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 OR valor_casilla='.' THEN '0' ELSE valor_casilla END),'0')) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
INTO DB_NQ77.DBO.AND_DET_0621_0
FROM DB_NQ77.DBO.AND_DET_0621
WHERE CASILLA IN (SELECT CASILLA FROM DB_NQ77.DBO.AND_CASILLA_0621) 
AND PERIODO BETWEEN '201401' AND '201612'
AND cod_veredito NOT IN (2,4)
AND DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
GROUP BY n_doc_declado
--OK--REVISAR SI ALGUNA CASILLA TIENE UN VALOR EXTRA�O

DROP TABLE DB_NQ77.DBO.AND_DET_0621_1
SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_0621
INTO DB_NQ77.DBO.AND_DET_0621_1
FROM DB_NQ77.DBO.AND_DET_0621_0
GROUP BY RUC
--SQL executed OK. Number of rows affected=188083 (3.24 secs)
--SQL executed OK. Number of rows affected=207842 (2.01 secs)
--SQL executed OK. Number of rows affected=207126 (0.33 secs)
--(21775 row(s) affected)

/***************************0626******************************/
--2 �	Declara F�cil - Formulario Virtual N� 626 Agentes de Retenci�n
DROP TABLE DB_NQ77.DBO.AND_CASILLA_0626
SELECT cod_casilla AS CASILLA
INTO DB_NQ77.DBO.AND_CASILLA_0626
FROM DB_NQ77.DBO.d2784dimnem_NO_ELIMINAR A
INNER JOIN DB_NQ77.DBO.p2813casilla_NO_ELIMINAR B
ON A.cod_nemotec=B.cod_nemotec
WHERE B.cod_formul='0626'
AND B.ind_tipdato='N'
AND SUBSTRING(B.cod_nemotec,1,3)='mto'
/*
select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0626" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("404","401","403","503","405","402","410","502","511","512","514"))
AND cod_veredito NOT IN ("2","4")
--127174 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_0626_TODO_F.TXT (704.40 secs)
--119494 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_0626.TXT (3753.88 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_0626
SELECT 
TOP 0 *
INTO DB_NQ77.DBO.AND_DET_0626
FROM OPENQUERY(DEANDRE,
'select FIRST 1 x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0626" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("404","401","403","503","405","402","410","502","511","512","514"))
AND cod_veredito NOT IN ("2","4")
')
*/

TRUNCATE TABLE DB_NQ77.DBO.AND_DET_0626
INSERT INTO DB_NQ77.DBO.AND_DET_0626
SELECT 
*
FROM OPENQUERY(DEANDRE,
'select  x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0626" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("404","401","403","503","405","402","410","502","511","512","514"))
AND cod_veredito NOT IN ("2","4")
')
--SQL executed OK. Number of rows affected=0 (0.68 secs)
--(31130 row(s) affected)

DROP TABLE DB_NQ77.DBO.AND_DET_0626_0
SELECT n_doc_declado AS RUC,
SUM(CASE 
WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
INTO DB_NQ77.DBO.AND_DET_0626_0
FROM DB_NQ77.DBO.AND_DET_0626
WHERE CASILLA IN (SELECT CASILLA FROM DB_NQ77.DBO.AND_CASILLA_0626)
AND PERIODO BETWEEN '201401' AND '201612'
AND DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
GROUP BY n_doc_declado
--OK--REVISAR SI ALGUNA CASILLA TIENE UN VALOR EXTRA�O
--SQL executed OK. Number of rows affected=685 (0.53 secs)
--SQL executed OK. Number of rows affected=590 (2.46 secs)
--SQL executed OK. Number of rows affected=131 (0.70 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_0626_1
SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_0626
INTO DB_NQ77.DBO.AND_DET_0626_1
FROM DB_NQ77.DBO.AND_DET_0626_0
GROUP BY RUC
--SQL executed OK. Number of rows affected=685 (0.14 secs)
--SQL executed OK. Number of rows affected=590 (0.23 secs)

/***************************0633******************************/
--3 �	Declara F�cil - Formulario Virtual N� 633 Agentes de Percepci�n Hidrocarburos
DROP TABLE DB_NQ77.DBO.AND_CASILLA_0633
SELECT cod_casilla AS CASILLA
INTO DB_NQ77.DBO.AND_CASILLA_0633
FROM DB_NQ77.DBO.d2784dimnem_NO_ELIMINAR A
INNER JOIN DB_NQ77.DBO.p2813casilla_NO_ELIMINAR B
ON A.cod_nemotec=B.cod_nemotec
WHERE B.cod_formul='0633'
AND B.ind_tipdato='N'
AND SUBSTRING(B.cod_nemotec,1,3)='mto'

/*
select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0633" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("410","403","404","402","405","503","401","502"))
AND cod_veredito NOT IN ("2","4")
--594 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_0633.TXT (3240.12 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_0633
SELECT 
TOP 0 *
INTO DB_NQ77.DBO.AND_DET_0633
FROM OPENQUERY(DEANDRE,
'select FIRST 1 x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0633" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("410","403","404","402","405","503","401","502"))
AND cod_veredito NOT IN ("2","4")
')
*/

TRUNCATE TABLE DB_NQ77.DBO.AND_DET_0633
INSERT INTO DB_NQ77.DBO.AND_DET_0633
SELECT 
*
FROM OPENQUERY(DEANDRE,
'select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0633" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("410","403","404","402","405","503","401","502"))
AND cod_veredito NOT IN ("2","4")
')
--(477 row(s) affected)

DROP TABLE DB_NQ77.DBO.AND_DET_0633_0
SELECT n_doc_declado AS RUC,
SUM(CASE 
WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
INTO DB_NQ77.DBO.AND_DET_0633_0
FROM DB_NQ77.DBO.AND_DET_0633
WHERE CASILLA IN (SELECT CASILLA FROM DB_NQ77.DBO.AND_CASILLA_0633)
AND PERIODO BETWEEN '201401' AND '201612'
AND DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
GROUP BY n_doc_declado
--SQL executed OK. Number of rows affected=17 (0.19 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_0633_1
SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_0633
INTO DB_NQ77.DBO.AND_DET_0633_1
FROM DB_NQ77.DBO.AND_DET_0633_0
GROUP BY RUC
--SQL executed OK. Number of rows affected=17 (0.00 secs)
--SQL executed OK. Number of rows affected=5 (0.05 secs)

/***************************0697******************************/
--4 �	Declara F�cil - Formulario Virtual N� 697 Agentes de Percepci�n Ventas Internas.
DROP TABLE DB_NQ77.DBO.AND_CASILLA_0697
SELECT cod_casilla AS CASILLA
INTO DB_NQ77.DBO.AND_CASILLA_0697
FROM DB_NQ77.DBO.d2784dimnem_NO_ELIMINAR A
INNER JOIN DB_NQ77.DBO.p2813casilla_NO_ELIMINAR B
ON A.cod_nemotec=B.cod_nemotec
WHERE B.cod_formul='0697'
AND B.ind_tipdato='N'
AND SUBSTRING(B.cod_nemotec,1,3)='mto'

/*
select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0697" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("401","402","403","404","405","410","502","503"))
AND cod_veredito NOT IN ("2","4")
--44190 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_0697.TXT (3213.30 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_0697
SELECT 
TOP 0 *
INTO DB_NQ77.DBO.AND_DET_0697
FROM OPENQUERY(DEANDRE,
'select FIRST 1 x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0697" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("401","402","403","404","405","410","502","503"))
AND cod_veredito NOT IN ("2","4")
')
*/
TRUNCATE TABLE DB_NQ77.DBO.AND_DET_0697
INSERT INTO DB_NQ77.DBO.AND_DET_0697
SELECT 
*
FROM OPENQUERY(DEANDRE,
'select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "0697" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("401","402","403","404","405","410","502","503"))
AND cod_veredito NOT IN ("2","4")
')
--(4790 row(s) affected)


DROP TABLE DB_NQ77.DBO.AND_DET_0697_0
SELECT n_doc_declado AS RUC,
SUM(CASE 
WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
INTO DB_NQ77.DBO.AND_DET_0697_0
FROM DB_NQ77.DBO.AND_DET_0697
WHERE CASILLA IN (SELECT CASILLA FROM DB_NQ77.DBO.AND_CASILLA_0697)
AND PERIODO BETWEEN '201401' AND '201612'
AND DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
GROUP BY n_doc_declado
--SQL executed OK. Number of rows affected=382 (0.73 secs)
--SQL executed OK. Number of rows affected=388 (0.79 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_0697_1
SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_0697
INTO DB_NQ77.DBO.AND_DET_0697_1
FROM DB_NQ77.DBO.AND_DET_0697_0
GROUP BY RUC
--SQL executed OK. Number of rows affected=382 (0.06 secs)
--SQL executed OK. Number of rows affected=388 (0.17 secs)
--SQL executed OK. Number of rows affected=39 (0.05 secs)

/***************************RENTA ANUAL 2 A�OS ANTES-- 0701,0691******************************/
--5 �	Declaraci�n de Renta Anual de Personas Naturales.
DROP TABLE DB_NQ77.DBO.AND_CASILLA_0691
SELECT cod_casilla AS CASILLA
INTO DB_NQ77.DBO.AND_CASILLA_0691
FROM DB_NQ77.DBO.d2784dimnem_NO_ELIMINAR A
INNER JOIN DB_NQ77.DBO.p2813casilla_NO_ELIMINAR B
ON A.cod_nemotec=B.cod_nemotec
WHERE B.cod_formul='0691'
AND B.ind_tipdato='N'
AND SUBSTRING(B.cod_nemotec,1,3)='mto'
--OK

DROP TABLE DB_NQ77.DBO.AND_CASILLA_0701
SELECT cod_casilla AS CASILLA
INTO DB_NQ77.DBO.AND_CASILLA_0701
FROM DB_NQ77.DBO.d2784dimnem_NO_ELIMINAR A
INNER JOIN DB_NQ77.DBO.p2813casilla_NO_ELIMINAR B
ON A.cod_nemotec=B.cod_nemotec
WHERE B.cod_formul='0701'
AND B.ind_tipdato='N'
AND SUBSTRING(B.cod_nemotec,1,3)='mto'
--OK

DROP TABLE DB_NQ77.DBO.AND_DET_0691
SELECT *
INTO DB_NQ77.DBO.AND_DET_0691
FROM DB_TERADATA.DBO.POC_RENTA_DET_F0691
WHERE n_doc_declado IN 
(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
AND PERIODO>='201401'
--SQL executed OK. Number of rows affected=785240 (5.71 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_0701
SELECT *
INTO DB_NQ77.DBO.AND_DET_0701
FROM DB_TERADATA.DBO.POC_RENTA_DET_F0701
WHERE n_doc_declado IN 
(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
AND PERIODO>='201401'
--SQL executed OK. Number of rows affected=755825 (4.34 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_RT_PN
SELECT n_doc_declado AS RUC,
SUM(CASE 
WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
INTO DB_NQ77.DBO.AND_DET_RT_PN
FROM DB_NQ77.DBO.AND_DET_0691
WHERE CASILLA COLLATE SQL_Latin1_General_CP1_CI_AS IN (SELECT CASILLA FROM DB_NQ77.DBO.AND_CASILLA_0691)
AND PERIODO BETWEEN '201401' AND '201612'
AND cod_veredito NOT IN (2,4)
AND DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
GROUP BY n_doc_declado
--SQL executed OK. Number of rows affected=14189 (4.29 secs)

INSERT INTO DB_NQ77.DBO.AND_DET_RT_PN
SELECT n_doc_declado AS RUC,
SUM(CASE 
WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
FROM DB_NQ77.DBO.AND_DET_0701
WHERE CASILLA COLLATE SQL_Latin1_General_CP1_CI_AS IN (SELECT CASILLA FROM DB_NQ77.DBO.AND_CASILLA_0701)
AND PERIODO BETWEEN '201401' AND '201612'
AND cod_veredito NOT IN (2,4)
AND DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
GROUP BY n_doc_declado
--SQL executed OK. Number of rows affected=13414 (2.92 secs)
--SQL executed OK. Number of rows affected=13415 (9.57 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_RT_PN_1
SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_RTA_PN
INTO DB_NQ77.DBO.AND_DET_RT_PN_1
FROM DB_NQ77.DBO.AND_DET_RT_PN
GROUP BY RUC
--SQL executed OK. Number of rows affected=17692 (0.25 secs)
--SQL executed OK. Number of rows affected=17693 (0.52 secs)
--SQL executed OK. Number of rows affected=1079 (11.34 secs)

/***************************RENTA ANUAL 2 A�OS ANTES-- 0702,0692******************************/
--6 �	Declaraci�n Renta Anual  � Tercera Categor�a  
DROP TABLE DB_NQ77.DBO.AND_CASILLA_0692
SELECT cod_casilla AS CASILLA
INTO DB_NQ77.DBO.AND_CASILLA_0692
FROM DB_NQ77.DBO.d2784dimnem_NO_ELIMINAR A
INNER JOIN DB_NQ77.DBO.p2813casilla_NO_ELIMINAR B
ON A.cod_nemotec=B.cod_nemotec
WHERE B.cod_formul='0692'
AND B.ind_tipdato='N'
AND SUBSTRING(B.cod_nemotec,1,3)='mto'
--
DROP TABLE DB_NQ77.DBO.AND_CASILLA_0702
SELECT cod_casilla AS CASILLA
INTO DB_NQ77.DBO.AND_CASILLA_0702
FROM DB_NQ77.DBO.d2784dimnem_NO_ELIMINAR A
INNER JOIN DB_NQ77.DBO.p2813casilla_NO_ELIMINAR B
ON A.cod_nemotec=B.cod_nemotec
WHERE B.cod_formul='0702'
AND B.ind_tipdato='N'
AND SUBSTRING(B.cod_nemotec,1,3)='mto'
--

DROP TABLE DB_NQ77.DBO.AND_DET_0692
SELECT *
INTO DB_NQ77.DBO.AND_DET_0692
FROM DB_TERADATA.DBO.POC_RENTA_DET_F0692
WHERE n_doc_declado IN 
(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
AND PERIODO>='201401'
--SQL executed OK. Number of rows affected=12343411 (31.86 secs)
--SQL executed OK. Number of rows affected=12344389 (37.27 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_0702
SELECT *
INTO DB_NQ77.DBO.AND_DET_0702
FROM DB_TERADATA.DBO.POC_RENTA_DET_F0702
WHERE n_doc_declado IN 
(SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
AND PERIODO>='201401'
--SQL executed OK. Number of rows affected=11400782 (29.60 secs)
--SQL executed OK. Number of rows affected=11401470 (39.49 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_RT_PJ
SELECT n_doc_declado AS RUC,
SUM(CASE 
WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
INTO DB_NQ77.DBO.AND_DET_RT_PJ
FROM DB_NQ77.DBO.AND_DET_0692
WHERE CASILLA COLLATE SQL_Latin1_General_CP1_CI_AS IN (SELECT CASILLA FROM DB_NQ77.DBO.AND_CASILLA_0692)
AND PERIODO BETWEEN '201401' AND '201612'
AND cod_veredito NOT IN (2,4)
AND DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
GROUP BY n_doc_declado
--SQL executed OK. Number of rows affected=117852 (6.29 secs)
--SQL executed OK. Number of rows affected=117863 (12.18 secs)

INSERT INTO DB_NQ77.DBO.AND_DET_RT_PJ
SELECT n_doc_declado AS RUC,
SUM(CASE 
WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
FROM DB_NQ77.DBO.AND_DET_0702
WHERE CASILLA COLLATE SQL_Latin1_General_CP1_CI_AS IN (SELECT CASILLA FROM DB_NQ77.DBO.AND_CASILLA_0702)
AND PERIODO BETWEEN '201401' AND '201612'
AND cod_veredito NOT IN (2,4)
AND DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
GROUP BY n_doc_declado
--SQL executed OK. Number of rows affected=106452 (11.43 secs)
--SQL executed OK. Number of rows affected=106460 (27.46 secs)


DROP TABLE DB_NQ77.DBO.AND_DET_RT_PJ_1
SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_RTA_PJ
INTO DB_NQ77.DBO.AND_DET_RT_PJ_1
FROM DB_NQ77.DBO.AND_DET_RT_PJ
GROUP BY RUC
--SQL executed OK. Number of rows affected=132166 (1.22 secs)
--SQL executed OK. Number of rows affected=132178 (2.16 secs)

/***************************ITF******************************/
--7 �	Declaraci�n del Impuesto a las Transacciones Financieras - ITF. No hay restricci�n al tipo de movimiento ni al tipo de operaci�n.

DROP TABLE DB_NQ77.DBO.AND_INF_ITF
SELECT cic_declado AS CIC, SUM(CASE WHEN mto_base IS NULL OR mto_base=0 THEN mto_impuesto/B.ITF ELSE mto_base END) AS MTO_BASE, SUM(mto_impuesto) AS MTO_IMP
INTO DB_NQ77.DBO.AND_INF_ITF
FROM DB_PROCESADO.DBO.TBL_ITF_2014 A
LEFT JOIN DB_PROCESADO.DBO.TBL_INCT_PERCO_ITF B
ON A.periodo_operacion=B.periodo
WHERE periodo_operacion>'201408'
AND cic_declado IN (SELECT CIC FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
GROUP BY cic_declado
--SQL executed OK. Number of rows affected=152448 (48.29 secs)
--SQL executed OK. Number of rows affected=152462 (48.36 secs)

INSERT INTO DB_NQ77.DBO.AND_INF_ITF
SELECT cic_declado AS CIC, SUM(CASE WHEN mto_base IS NULL OR mto_base=0 THEN mto_impuesto/B.ITF ELSE mto_base END) AS MTO_BASE, SUM(mto_impuesto) AS MTO_IMP
FROM DB_PROCESADO.DBO.TBL_ITF_2015 A
LEFT JOIN DB_PROCESADO.DBO.TBL_INCT_PERCO_ITF B
ON A.periodo_operacion=B.periodo
WHERE periodo_operacion>'201408'
AND cic_declado IN (SELECT CIC FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
GROUP BY cic_declado
--SQL executed OK. Number of rows affected=179666 (33.87 secs)

INSERT INTO DB_NQ77.DBO.AND_INF_ITF
SELECT cic_declado AS CIC, SUM(CASE WHEN mto_base IS NULL OR mto_base=0 THEN mto_impuesto/B.ITF ELSE mto_base END) AS MTO_BASE, SUM(mto_impuesto) AS MTO_IMP
FROM DB_PROCESADO.DBO.TBL_ITF_2016 A
LEFT JOIN DB_PROCESADO.DBO.TBL_INCT_PERCO_ITF B
ON A.periodo_operacion=B.periodo
WHERE periodo_operacion>'201408'
AND cic_declado IN (SELECT CIC FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
GROUP BY cic_declado
--SQL executed OK. Number of rows affected=155512 (31.44 secs)

DROP TABLE DB_NQ77.DBO.AND_INF_ITF_0
SELECT CIC,
SUM(CASE 
WHEN ISNULL(MTO_BASE,0) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
INTO DB_NQ77.DBO.AND_INF_ITF_0
FROM DB_NQ77.DBO.AND_INF_ITF
GROUP BY CIC
--SQL executed OK. Number of rows affected=207428 (1.25 secs)

DROP TABLE DB_NQ77.DBO.AND_INF_ITF_1
SELECT CIC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_ITF
INTO DB_NQ77.DBO.AND_INF_ITF_1
FROM DB_NQ77.DBO.AND_INF_ITF_0
GROUP BY CIC
--SQL executed OK. Number of rows affected=207449 (1.03 secs)
--SQL executed OK. Number of rows affected=46416 (114.29 secs)

/***************************DETRACCIONES******************************/
--8 
DROP TABLE DB_NQ77.DBO.AND_INFRO_ADQUIRIENTE
SELECT num_doc_adq AS RUC
INTO DB_NQ77.DBO.AND_INFRO_ADQUIRIENTE
FROM DB_PROCESADO.DBO.TBL_INCT_DETRAC_MAESTRO
WHERE DATEDIFF(MONTH,  CONVERT(DATE,SUBSTRING(fec_pag,7,4)+'/'+SUBSTRING(fec_pag,1,2)+'/'+SUBSTRING(fec_pag,4,2) ), '22-09-2016')<=24
AND num_doc_adq IN (SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
GROUP BY num_doc_adq
--SQL executed OK. Number of rows affected=55398 (84.25 secs)
--SQL executed OK. Number of rows affected=62562 (114.41 secs)
--SQL executed OK. Number of rows affected=63092 (71.16 secs)
--SQL executed OK. Number of rows affected=63093 (111.45 secs)

DROP TABLE DB_NQ77.DBO.AND_INFRO_PROVEEDOR
SELECT num_ruc_prov AS RUC
INTO DB_NQ77.DBO.AND_INFRO_PROVEEDOR
FROM DB_PROCESADO.DBO.TBL_INCT_DETRAC_MAESTRO
WHERE DATEDIFF(MONTH,  CONVERT(DATE,SUBSTRING(fec_pag,7,4)+'/'+SUBSTRING(fec_pag,1,2)+'/'+SUBSTRING(fec_pag,4,2) ), '22-09-2016')<=24
AND num_ruc_prov IN (SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
GROUP BY num_ruc_prov
--SQL executed OK. Number of rows affected=72545 (17.47 secs)
--SQL executed OK. Number of rows affected=78993 (103.36 secs)
--SQL executed OK. Number of rows affected=79595 (13.45 secs)
--SQL executed OK. Number of rows affected=79596 (75.26 secs)
--
/***************************1666******************************/
--9 �	Formulario Virtual de Ganancias de Capital y Otras Rentas N� 1666
DROP TABLE DB_NQ77.DBO.AND_CASILLA_1666
SELECT cod_casilla AS CASILLA
INTO DB_NQ77.DBO.AND_CASILLA_1666
FROM DB_NQ77.DBO.d2784dimnem_NO_ELIMINAR A
INNER JOIN DB_NQ77.DBO.p2813casilla_NO_ELIMINAR B
ON A.cod_nemotec=B.cod_nemotec
WHERE B.cod_formul='1666'
AND B.ind_tipdato='N'
AND SUBSTRING(B.cod_nemotec,1,3)='mto'

/*
select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "1666" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("326","329","336","338","347","349","369","389","399","500","501","502","503","504","505","506","507","516","517","518","519","550","551","552","553","554","555","599"))
AND cod_veredito NOT IN ("2","4")
--168 rows of data written to d:\Users\asanchezb\Desktop\t2782djcab_1666.TXT (3836.64 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_1666
SELECT 
TOP 0 *
INTO DB_NQ77.DBO.AND_DET_1666
FROM OPENQUERY(DEANDRE,
'select FIRST 1 x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "1666" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("326","329","336","338","347","349","369","389","399","500","501","502","503","504","505","506","507","516","517","518","519","550","551","552","553","554","555","599"))
AND cod_veredito NOT IN ("2","4")
')
*/
TRUNCATE TABLE DB_NQ77.DBO.AND_DET_1666
INSERT INTO DB_NQ77.DBO.AND_DET_1666
SELECT 
*
FROM OPENQUERY(DEANDRE,
'select x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta, x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1, bdun1682.cic_ruc_andres x2
where (x0.cod_formul = "1666" and ((x0.num_periodo BETWEEN "201401" AND "201612") and x0.cod_cic=x2.cic))
AND ((x0.num_nabono = x1.num_nabono AND x0.cod_formul = x1.cod_formul  AND x0.num_orden = x1.num_orden)   
AND x1.cod_casilla IN ("326","329","336","338","347","349","369","389","399","500","501","502","503","504","505","506","507","516","517","518","519","550","551","552","553","554","555","599"))
AND cod_veredito NOT IN ("2","4")
')
--SQL executed OK. Number of rows affected=0 (0.68 secs)
--(84 row(s) affected)

DROP TABLE DB_NQ77.DBO.AND_DET_1666_0
SELECT n_doc_declado AS RUC,
SUM(CASE 
WHEN CONVERT(NUMERIC(32,2),ISNULL((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END),'0')) > 0
THEN 1 
ELSE 0 END) AS IND_MTO
INTO DB_NQ77.DBO.AND_DET_1666_0
FROM DB_NQ77.DBO.AND_DET_1666
WHERE CASILLA IN (SELECT CASILLA FROM DB_NQ77.DBO.AND_CASILLA_1666)
AND PERIODO BETWEEN '201401' AND '201612'
AND DATEDIFF(MONTH,  f_presenta, '22-09-2016')<=24
GROUP BY n_doc_declado
--SQL executed OK. Number of rows affected=2 (0.22 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_1666_1
SELECT RUC, MAX(CASE WHEN IND_MTO=1 THEN 1 ELSE 0 END) IND_MTO_1666
INTO DB_NQ77.DBO.AND_DET_1666_1
FROM DB_NQ77.DBO.AND_DET_1666_0
GROUP BY RUC
--SQL executed OK. Number of rows affected=2 (0.17 secs)
--SQL executed OK. Number of rows affected=1 (0.09 secs)

/*************************** CAVALI ******************************/
-----------------------------------------------------------------------------------------
--10 �	Con informaci�n de retenci�n de rentas de 2da (ganancias de K informados por CAVALI).

/*
Select * from informix.vw_cab_unicas
where formulario IN ('1666','0617') and periodo between '201401' and '201612'
--1520907 rows of data written to d:\Users\asanchezb\Desktop\vw_cab_unicas_1666_0617.TXT (180.46 secs)
*/

DROP TABLE DB_NQ77.DBO.vw_cab_unicas_0617_1666
SELECT TOP 0 *
INTO DB_NQ77.DBO.vw_cab_unicas_0617_1666
FROM OPENQUERY(DEANDRE,
'Select FIRST 1 * from informix.vw_cab_unicas'
)

/*
Select * from informix.vw_otrasret
where periodo between '201401' and '201612'
--5162279 rows of data written to d:\Users\asanchezb\Desktop\vw_otrasret.TXT (1098.66 secs)
*/

DROP TABLE DB_NQ77.DBO.vw_otrasret
SELECT TOP 0 *
INTO DB_NQ77.DBO.vw_otrasret
FROM OPENQUERY(DEANDRE,
'Select FIRST 1 * from informix.vw_otrasret'
)

DROP TABLE DB_NQ77.DBO.AND_DET_2DA_OTRA
SELECT A.*
INTO DB_NQ77.DBO.AND_DET_2DA_OTRA
FROM DB_NQ77.DBO.vw_otrasret A
INNER JOIN DB_NQ77.DBO.vw_cab_unicas_0617_1666 B
ON A.nota_abono=B.nabono
AND A.formulario=B.formulario
AND A.n_orden=B.nro_orden
AND B.tributo='030202'
--SQL executed OK. Number of rows affected=4666716 (17.79 secs)
--SQL executed OK. Number of rows affected=4650704 (24.04 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_2DA_OTRA_0
SELECT DISTINCT 
periodo, formulario,cic_decpdt, tipo_dcto_decpdt, nro_dcto_decpdt, nro_dcto_ret,  tipo_dcto_ret, 0 AS CIC,
(CASE
WHEN caracter_renta='01' THEN caracter_renta+' - Renta gravada'
WHEN caracter_renta='02' THEN caracter_renta+' - Renta Exonerada'
WHEN caracter_renta='03' THEN caracter_renta+' - Renta Inafecta'
END) AS caracter_renta, 

(CASE
WHEN tipo_renta='0' THEN  tipo_renta+ ' - NO APLICA'
WHEN tipo_renta='1' THEN  tipo_renta+ ' - Art 72'
WHEN tipo_renta='2' THEN  tipo_renta+ ' - Art 73'
WHEN tipo_renta='3' THEN  tipo_renta+ ' - Art 77 A inc A. LIR'
WHEN tipo_renta='4' THEN  tipo_renta+ ' - Art 77 A penultimo parr LIR'
WHEN tipo_renta='5' THEN  tipo_renta+ ' - Art 72 seg parr LIB'
WHEN tipo_renta='6' THEN  tipo_renta+ ' - Enajenaci�n de Valores mobiliarios'
WHEN tipo_renta='7' THEN  tipo_renta+ ' - Intereses'
END) AS tipo_renta

INTO DB_NQ77.DBO.AND_DET_2DA_OTRA_0 
FROM DB_NQ77.DBO.AND_DET_2DA_OTRA 
WHERE tipo_retencion='1'
AND PERIODO>'201408'
AND cic_decpdt=15258406
--SQL executed OK. Number of rows affected=1552766 (7.07 secs)
--SQL executed OK. Number of rows affected=21495 (5.26 secs)

UPDATE A
SET CIC=B.CIC
FROM DB_NQ77.DBO.AND_DET_2DA_OTRA_0 A
INNER JOIN DB_PADRON.DBO.TBL_GPGF_IDENTIFICADOS B
ON A.tipo_dcto_ret=B.TIPO_DCTO_DECLADO
AND A.nro_dcto_ret=B.N_DCTO_DECLADO COLLATE SQL_Latin1_General_CP1_CI_AS
--SQL executed OK. Number of rows affected=36875 (1.90 secs)
--SQL executed OK. Number of rows affected=21201 (7.92 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_2DA_OTRA_1
SELECT CIC
INTO DB_NQ77.DBO.AND_DET_2DA_OTRA_1
FROM DB_NQ77.DBO.AND_DET_2DA_OTRA_0
WHERE tipo_renta = '6 - Enajenaci�n de Valores mobiliarios'
GROUP BY CIC
--SQL executed OK. Number of rows affected=5680 (0.39 secs)


/*************************** PDT NOTARIO ******************************/
-----------------------------------------------------------------------------------------
--11 �	Con informaci�n en PDT Notarios.   
DROP TABLE DB_NQ77.DBO.AND_DET_NOT_OTRA_0
SELECT cod_tipdocoto, num_docoto, CONVERT(INT, 0) AS CIC
INTO DB_NQ77.DBO.AND_DET_NOT_OTRA_0
FROM DB_PROCESADO.DBO.TBL_INCT_NOTARIOS_2014
WHERE DATEDIFF(MONTH, fec_numesc, '22-09-2016')<=24
AND mto_actjur>0
GROUP BY cod_tipdocoto, num_docoto
--SQL executed OK. Number of rows affected=464516 (2.17 secs)

INSERT INTO DB_NQ77.DBO.AND_DET_NOT_OTRA_0
SELECT cod_tipdocoto, num_docoto, CONVERT(INT, 0) AS CIC
FROM DB_PROCESADO.DBO.TBL_INCT_NOTARIOS_2015
WHERE DATEDIFF(MONTH, fec_numesc, '22-09-2016')<=24
AND mto_actjur>0
GROUP BY cod_tipdocoto, num_docoto
--SQL executed OK. Number of rows affected=1127494 (4.90 secs)

UPDATE A
SET CIC=B.CIC
FROM DB_NQ77.DBO.AND_DET_NOT_OTRA_0 A
INNER JOIN DB_PADRON.DBO.TBL_GPGF_IDENTIFICADOS B
ON A.cod_tipdocoto=B.TIPO_DCTO_DECLADO
AND A.num_docoto=B.N_DCTO_DECLADO COLLATE SQL_Latin1_General_CP1_CI_AS
--SQL executed OK. Number of rows affected=1573303 (16.26 secs)

DROP TABLE DB_NQ77.DBO.AND_DET_NOT_OTRA_1
SELECT CIC
INTO DB_NQ77.DBO.AND_DET_NOT_OTRA_1
FROM DB_NQ77.DBO.AND_DET_NOT_OTRA_0
GROUP BY CIC
--SQL executed OK. Number of rows affected=1450488 (1.03 secs)

--------------------------------------------------------------
DROP TABLE DB_NQ77.DBO.AND_DDJJ_TODO_MAY_MTO_1
SELECT A.RUC 
INTO DB_NQ77.DBO.AND_DDJJ_TODO_MAY_MTO_1
FROM 
(
SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_NQ77.DBO.AND_DET_0621_1 WHERE IND_MTO_0621=1--OK
UNION ALL
SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_NQ77.DBO.AND_DET_0626_1 WHERE IND_MTO_0626=1--OK
UNION ALL
SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_NQ77.DBO.AND_DET_0633_1 WHERE IND_MTO_0633=1--OK
UNION ALL
SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_NQ77.DBO.AND_DET_0697_1 WHERE IND_MTO_0697=1--OK
UNION ALL
SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_NQ77.DBO.AND_DET_RT_PJ_1 WHERE IND_MTO_RTA_PJ=1 --OK
UNION ALL
SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_NQ77.DBO.AND_DET_RT_PN_1 WHERE IND_MTO_RTA_PN=1 --OK
UNION ALL
SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_NQ77.DBO.AND_DET_1666_1 WHERE IND_MTO_1666=1 --OK
UNION ALL
SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_NQ77.DBO.AND_INFRO_ADQUIRIENTE --OK
UNION ALL
SELECT RUC COLLATE SQL_Latin1_General_CP1_CI_AS RUC FROM DB_NQ77.DBO.AND_INFRO_PROVEEDOR --OK
) A
GROUP BY A.RUC
--SQL executed OK. Number of rows affected=1594777 (3.62 secs)
--SQL executed OK. Number of rows affected=127495 (0.23 secs)
--SQL executed OK. Number of rows affected=207854 (0.31 secs)
--SQL executed OK. Number of rows affected=21382 (2.73 secs)
--SQL executed OK. Number of rows affected=117118 (0.34 secs)
--SQL executed OK. Number of rows affected=117123 (4.96 secs)
--SQL executed OK. Number of rows affected=8145 (1.14 secs)

DROP TABLE DB_NQ77.DBO.AND_DDJJ_TODO_MAY_MTO_2
SELECT CIC
INTO DB_NQ77.DBO.AND_DDJJ_TODO_MAY_MTO_2
FROM
(
SELECT CIC FROM DB_NQ77.DBO.AND_INF_ITF_1 
UNION ALL
SELECT CIC FROM DB_NQ77.DBO.AND_DET_2DA_OTRA_1 
UNION ALL
SELECT CIC FROM DB_NQ77.DBO.AND_DET_NOT_OTRA_1
) A
GROUP BY CIC
--SQL executed OK. Number of rows affected=1630374 (3.29 secs)
--SQL executed OK. Number of rows affected=1630392 (2.86 secs)
--SQL executed OK. Number of rows affected=1496211 (2.18 secs)

UPDATE A
SET TIP_EXC_2_I_7='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.AND_DDJJ_TODO_MAY_MTO_1  B
ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS
--SQL executed OK. Number of rows affected=127495 (6.45 secs)
--SQL executed OK. Number of rows affected=21382 (15.10 secs)
--SQL executed OK. Number of rows affected=117118 (5.02 secs)
--SQL executed OK. Number of rows affected=117123 (5.29 secs)
--SQL executed OK. Number of rows affected=8145 (19.56 secs)

UPDATE A
SET TIP_EXC_2_I_7='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.AND_DDJJ_TODO_MAY_MTO_2  B
ON A.CIC=B.CIC
AND A.CIC<>0
--SQL executed OK. Number of rows affected=105 (1.88 secs)
--SQL executed OK. Number of rows affected=114 (1.56 secs)
--SQL executed OK. Number of rows affected=211711 (6.58 secs)
--SQL executed OK. Number of rows affected=211735 (7.99 secs)
--SQL executed OK. Number of rows affected=48987 (7.19 secs)

------------------------------------------------------------------------------------------------------------------------------------
--I - A - 8

DROP TABLE DB_NQ77.DBO.TBL_Solicitudes_Devolucion
SELECT *
INTO DB_NQ77.DBO.TBL_Solicitudes_Devolucion
FROM DB_GPGD.DBO.TBL_Solicitudes_Devolucion
WHERE A�O=2016
AND MES='09'
AND RUC IN (SELECT RUC FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2)
--SQL executed OK. Number of rows affected=436 (3.56 secs)
--SQL executed OK. Number of rows affected=150 (1.75 secs)

DROP TABLE DB_NQ77.DBO.TBL_Solicitudes_Devolucion_1
SELECT RUC
INTO DB_NQ77.DBO.TBL_Solicitudes_Devolucion_1
FROM DB_NQ77.DBO.TBL_Solicitudes_Devolucion
WHERE DATEDIFF(MONTH,  fec_doc, '22-09-2016')<=24
AND cod_tip_sol='02'
GROUP BY RUC


UPDATE A
SET TIP_EXC_2_I_8='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.TBL_Solicitudes_Devolucion_1  B
ON A.RUC=B.RUC
AND A.CIC<>0
--SQL executed OK. Number of rows affected=87 (1.56 secs)
--SQL executed OK. Number of rows affected=9 (1.78 secs)

/****************************************************************************************************/
--EXCLUSIONES DEUDORES PROCESOS CENTRALIZADOS
/****************************************************************************************************/

------------------------------------------------------------------------------------------------------------------------------------ 
--II - A  
--2� Estado Activo
UPDATE A
SET TIP_EXC_2_II_A='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_DATA_WH.PADRON.TB_CONTRIBUYENTE  B
ON A.RUC=B.num_ruc 
WHERE B.id_estcontri=0
--SQL executed OK. Number of rows affected=170317 (78.22 secs)
--SQL executed OK. Number of rows affected=191257 (43.36 secs)
--SQL executed OK. Number of rows affected=189923 (161.30 secs)
--SQL executed OK. Number of rows affected=32990 (72.29 secs)

------------------------------------------------------------------------------------------------------------------------------------ 
--II - B
--3� Condici�n de Domicilio: Habido
UPDATE A
SET TIP_EXC_2_II_B='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_DATA_WH.PADRON.TB_CONTRIBUYENTE  B
ON A.RUC=B.num_ruc 
WHERE B.id_conddom=0
--SQL executed OK. Number of rows affected=183763 (296.61 secs)
--SQL executed OK. Number of rows affected=204326 (63.73 secs)
--SQL executed OK. Number of rows affected=207503 (27.36 secs)
--SQL executed OK. Number of rows affected=207431 (29.13 secs)
--SQL executed OK. Number of rows affected=54990 (10.34 secs)

-------------------------------------------------------------------------------------------------------------------------------------
--II - C
--1� Que tengan perfil de comportamiento Cumplidor, Inducible o Mixto.
DROP TABLE DB_NQ77.DBO.tbl_Padron_segmento_pago
SELECT NUM_RUC AS RUC,id_subsegpago, CONVERT(INT,NULL) AS id_perfil 
INTO DB_NQ77.DBO.tbl_Padron_segmento_pago
FROM DB_DATA_WH.PADRON.TB_SEGMENTO_PAGO_HIST WITH (NOLOCK)
WHERE YEAR(FEC_FINVIG)=2100
--SQL executed OK. Number of rows affected=10856159 (7.66 secs)
--SQL executed OK. Number of rows affected=10776179 (19.56 secs)

UPDATE A
SET id_perfil=C.id_perfilpago
FROM DB_NQ77.DBO.tbl_Padron_segmento_pago A WITH (NOLOCK)
INNER JOIN DB_DATA_WH.PADRON.TB_SUBSEGPAGO B WITH (NOLOCK)
ON A.id_subsegpago=B.id_subsegpago 
INNER JOIN DB_DATA_WH.PADRON.TB_SEGPAGO C WITH (NOLOCK)
ON B.id_segpago=C.id_segpago 
--SQL executed OK. Number of rows affected=10727904 (38.14 secs)
--SQL executed OK. Number of rows affected=10776179 (57.83 secs)

UPDATE A
SET TIP_EXC_2_II_C='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.tbl_Padron_segmento_pago  B
ON A.RUC=B.RUC COLLATE SQL_Latin1_General_CP1_CI_AS
WHERE id_perfil IN (4,5,0)
--SQL executed OK. Number of rows affected=91754 (8.86 secs)
--SQL executed OK. Number of rows affected=65259 (6.91 secs)
--SQL executed OK. Number of rows affected=70765 (6.94 secs)
--SQL executed OK. Number of rows affected=14569 (3.96 secs)

-------------------------------------------------------------------------------------------------------------------------------------
--II - D
--1� Que tengan bienes registrados en SUNARP (En caso PPNN cruce masivo por DNI y/o Apellidos y Nombres y en PPJJ cruce masivo por identidad de Raz�n Social). 

DROP TABLE DB_NQ77.DBO.AND_INFR_SUNARP
SELECT COD_CIC AS CIC
INTO DB_NQ77.DBO.AND_INFR_SUNARP
FROM
(
SELECT COD_CIC FROM DB_NQ77.DBO.AND_SUNARP_BUQUE WHERE COD_CIC<>0 AND nom_partic='PROPIETARIO' AND ind_estado=1 
UNION ALL
SELECT COD_CIC FROM DB_NQ77.DBO.AND_SUNARP_EMBAR WHERE COD_CIC<>0 AND nom_partic='PROPIETARIO' AND ind_estado=1
UNION ALL
SELECT COD_CIC FROM DB_NQ77.DBO.AND_SUNARP_AERO WHERE COD_CIC<>0 AND nom_partic='PROPIETARIO' AND ind_estado=1
UNION ALL
SELECT COD_CIC FROM DB_NQ77.DBO.AND_SUNARP_PRED WHERE COD_CIC<>0 AND nom_partic='PROPIETARIO' AND ind_estado=1
UNION ALL
SELECT COD_CIC FROM DB_NQ77.DBO.AND_SUNARP_VEHI WHERE COD_CIC<>0 AND nom_partic='TITULAR' AND ind_estado=1
) A
GROUP BY COD_CIC
--SQL executed OK. Number of rows affected=18258 (7.07 secs)
--SQL executed OK. Number of rows affected=18267 (2.34 secs)

UPDATE A
SET TIP_EXC_2_II_D='X'
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 A
INNER JOIN DB_NQ77.DBO.AND_INFR_SUNARP  B
ON A.CIC=B.CIC
AND A.CIC<>0
--SQL executed OK. Number of rows affected=15798 (1.84 secs)
--SQL executed OK. Number of rows affected=18283 (1.72 secs)
--SQL executed OK. Number of rows affected=18258 (1.90 secs)
--SQL executed OK. Number of rows affected=12514 (1.92 secs)

/***********************************************************************************************/
DROP TABLE DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_6
SELECT *
INTO DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_6
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2
WHERE TIP_EXC_2_A<>'X' 
AND TIP_EXC_2_B<>'X' 
AND TIP_EXC_2_C<>'X' 
AND TIP_EXC_2_I_1<>'X' 
AND TIP_EXC_2_I_2<>'X' 
AND TIP_EXC_2_I_3<>'X' 
AND TIP_EXC_2_I_4<>'X' 
AND TIP_EXC_2_I_5<>'X' 
AND TIP_EXC_2_I_6<>'X' 
AND TIP_EXC_2_I_7<>'X' 
AND TIP_EXC_2_II_A<>'X' 
AND TIP_EXC_2_II_B<>'X' 
AND TIP_EXC_2_II_C<>'X' 
AND TIP_EXC_2_II_D<>'X'
--SQL executed OK. Number of rows affected=50776 (0.86 secs)
--SQL executed OK. Number of rows affected=49978 (7.75 secs)
--SQL executed OK. Number of rows affected=91191 (3.36 secs)

CREATE INDEX IND_RUC ON DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_6 (RUC)
--OK

CREATE INDEX IND_RUC ON DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_2 (RUC)
--OK

DROP TABLE DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_4
SELECT RUC,
COUNT(*) AS CNT_VALORES,
SUM(mto_trib+mto_int+mto_cap+mto_rec) AS MTO_INSOLUTO,
SUM(trib_exig+int_exig+cap_exig+rec_exig) AS MTO_SALDO_EXIGIBLE,
SUM(sal_trib+sal_int+sal_cap+sal_rec) AS MTO_SALDO_TOTAL
INTO DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_4
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_1
GROUP BY RUC
--(362767 row(s) affected)
--SQL executed OK. Number of rows affected=202584 (3.37 secs)

CREATE INDEX IND_RUC ON DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_4 (RUC)
--OK

DROP TABLE DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_3
SELECT 
D.cod_depen,
D.nom_depen,
A.RUC,
replace(B.NOM_RAZSOC,'"','') AS NOM_RAZSOC,
C.des_conddom,
E.des_estcontri,
T.des_tipocontri,
PP.des_perfilpago,
SF.nom_segfisca,
AA.CNT_VALORES,
AA.MTO_INSOLUTO,
AA.MTO_SALDO_EXIGIBLE,
AA.MTO_SALDO_TOTAL
INTO DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_3
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_6 A
INNER JOIN DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_4 AA
ON AA.RUC=A.RUC
LEFT JOIN  DB_DATA_WH.PADRON.TB_CONTRIBUYENTE B
ON A.RUC=B.NUM_RUC
LEFT JOIN DB_DATA_WH.PADRON.TB_DEPENDENCIA D
ON B.ID_DEPEN=D.ID_DEPEN
LEFT JOIN DB_DATA_WH.PADRON.TB_CONDI_DOMIC_CONTRI C
ON B.ID_CONDDOM=C.ID_CONDDOM
LEFT JOIN DB_DATA_WH.PADRON.TB_ESTADO_CONTRIBUYENTE E
ON B.ID_ESTCONTRI=E.ID_ESTCONTRI
LEFT JOIN DB_DATA_WH.PADRON.TB_TIPO_CONTRIBUYENTE T
ON B.ID_TIPCONTRI=T.ID_TIPCONTRI

LEFT JOIN DB_DATA_WH.PADRON.TB_SUBSEGPAGO SSP
ON B.ID_SUBSEGPAGO=SSP.ID_SUBSEGPAGO
LEFT JOIN DB_DATA_WH.PADRON.TB_SEGPAGO SP
ON SSP.ID_SEGPAGO=SP.ID_SEGPAGO
LEFT JOIN DB_DATA_WH.PADRON.TB_PERFIL_PAGO PP
ON SP.ID_PERFILPAGO=PP.ID_PERFILPAGO

LEFT JOIN DB_DATA_WH.PADRON.TB_SEGMENTOFISCA SF
ON B.ID_SEGFISCA=SF.ID_SEGFISCA
--SQL executed OK. Number of rows affected=50776 (21.37 secs)
--SQL executed OK. Number of rows affected=49978 (7.64 secs)
--SQL executed OK. Number of rows affected=91191 (75.89 secs)

CREATE INDEX IND_RUC ON DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_3 (RUC)

DROP TABLE DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
SELECT
A.RUC,
replace(B.NOM_RAZSOC,'"','') AS NOM_RAZSOC,
A.cod_valor,  A.tipo_doc,  year(A.fec_coa)*100+month(A.fec_coa) as periodo,  A.cod_trib,  
(A.mto_trib+A.mto_int+A.mto_cap+A.mto_rec) AS MTO_INSOLUTO,  
(A.trib_exig+A.int_exig+A.cap_exig+A.rec_exig) AS MTO_SALDO_EXIGIBLE,
(A.sal_trib+A.sal_int+A.sal_cap+A.sal_rec) AS MTO_SALDO_TOTAL,
ROW_NUMBER() OVER (ORDER BY A.RUC DESC) AS ord
INTO DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_1 A
INNER JOIN DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_3 B
ON A.RUC=B.RUC

SELECT RUC, NOM_RAZSOC, cod_valor, tipo_doc, periodo, cod_trib, MTO_INSOLUTO, MTO_SALDO_EXIGIBLE, MTO_SALDO_TOTAL
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
WHERE ORD<=500000

SELECT RUC, NOM_RAZSOC, cod_valor, tipo_doc, periodo, cod_trib, MTO_INSOLUTO, MTO_SALDO_EXIGIBLE, MTO_SALDO_TOTAL
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
WHERE ORD>500000 AND ORD<=1000000

SELECT RUC, NOM_RAZSOC, cod_valor, tipo_doc, periodo, cod_trib, MTO_INSOLUTO, MTO_SALDO_EXIGIBLE, MTO_SALDO_TOTAL
FROM DB_NQ77.DBO.AND_SALDOS_VALORES_PENDIENTES_6_1
WHERE ORD>1000000 

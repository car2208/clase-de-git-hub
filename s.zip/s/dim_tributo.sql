SELECT *INTO db_proc_cdp.dbo.d2712dimtrib FROM  OPENQUERY(BDU,'Select * from informix.d2712dimtrib')

SELECT 
DISTINCT cod_tributo,des_sigtributo,des_tributo,cod_subtri,des_subtri,cod_trigener,des_trigener
FROM db_proc_cdp.dbo.d2712dimtrib 
ORDER BY cod_tributo


INSERT INTO DESA.[tb_tributo]


SELECT DISTINCT cod_tributo,des_sigtributo,des_tributo,cod_subtri,
des_subtri,cod_trigener,des_trigener
FROM db_proc_cdp.DBO.d2712dimtrib 


--SELECT * FROM db_gpgd.dbo.param_tributo
--WHERE cod_trib IN (
--SELECT cod_trib COLLATE SQL_Latin1_General_CP1_CI_AS FROM db_gpgd.dbo.param_tributo
--EXCEPT
--SELECT distinct cod_tributo FROM db_proc_cdp.DBO.d2712dimtrib
--)

--SELECT * FROM db_proc_cdp.DBO.d2712dimtrib
--WHERE cod_tributo in (
--SELECT distinct cod_tributo FROM db_proc_cdp.DBO.d2712dimtrib
--EXCEPT
--SELECT cod_trib COLLATE SQL_Latin1_General_CP1_CI_AS FROM db_gpgd.dbo.param_tributo
--)



--SELECT  A.cod_trib COLLATE SQL_Latin1_General_CP1_CI_AS,
--		A.des_corta COLLATE SQL_Latin1_General_CP1_CI_AS,
--		A.desctrib COLLATE SQL_Latin1_General_CP1_CI_AS,
--        A.cod_subtri COLLATE SQL_Latin1_General_CP1_CI_AS,
--	    A.des_subtri COLLATE SQL_Latin1_General_CP1_CI_AS,
--	    A.cod_trigen COLLATE SQL_Latin1_General_CP1_CI_AS,
--	    A.des_trigen COLLATE SQL_Latin1_General_CP1_CI_AS,B.*
--FROM db_gpgd.dbo.param_tributo  A 
--FULL JOIN 
--(SELECT DISTINCT cod_tributo,des_sigtributo,des_tributo,cod_subtri,des_subtri,cod_trigener,des_trigener FROM db_proc_cdp.DBO.d2712dimtrib ) B
--ON A.COD_TRIB=B.COD_TRIBUTO COLLATE SQL_Latin1_General_CP1_CI_AS


		SELECT  cod_trib COLLATE SQL_Latin1_General_CP1_CI_AS,
				des_corta COLLATE SQL_Latin1_General_CP1_CI_AS,
				desctrib COLLATE SQL_Latin1_General_CP1_CI_AS,
				cod_subtri COLLATE SQL_Latin1_General_CP1_CI_AS,
				des_subtri COLLATE SQL_Latin1_General_CP1_CI_AS,
				cod_trigen COLLATE SQL_Latin1_General_CP1_CI_AS,
				des_trigen COLLATE SQL_Latin1_General_CP1_CI_AS 
		FROM db_gpgd.dbo.param_tributo
		WHERE cod_trib NOT IN (
								SELECT cod_trib COLLATE SQL_Latin1_General_CP1_CI_AS FROM db_gpgd.dbo.param_tributo
								EXCEPT
								SELECT distinct cod_tributo FROM db_proc_cdp.DBO.d2712dimtrib
							  )
		UNION ALL
		SELECT cod_tributo,des_sigtributo,des_tributo,cod_subtri,des_subtri,cod_trigener,des_trigener 
		FROM db_proc_cdp.DBO.d2712dimtrib
		WHERE cod_tributo IN (
								SELECT distinct cod_tributo FROM db_proc_cdp.DBO.d2712dimtrib
								EXCEPT
								SELECT cod_trib COLLATE SQL_Latin1_General_CP1_CI_AS FROM db_gpgd.dbo.param_tributo
							 ) AND cod_tributo<>'06080'



/***************************************************************************************************************************************************************************/
	USE db_proc_cdp
	GO
	
	DROP TABLE desa.tb_entidad
	CREATE TABLE desa.tb_entidad
	(
	id_entidad int primary key,
	desc_entidad varchar(150) ,
	)

	DROP TABLE  desa.tb_infraccion
	CREATE TABLE desa.tb_infraccion
	(
		id_infraccion int identity(0,1) primary key,
		art_infraccion int not null,
		num_infraccion int not null,
		desc_infraccion varchar(250),
		norma_leg varchar(100),
		fec_inivig date,
		fec_finvig date 
	)

	DROP TABLE desa.[tb_tributo]
	CREATE TABLE desa.[tb_tributo](
		[cod_tributo] [char](6) NOT NULL PRIMARY KEY,
		[des_sigtributo] [char](6) NULL,
		[des_tributo] [char](60) NULL,
		[cod_subtri] [char](4) NULL,
		[des_subtri] [char](45) NULL,
		[cod_trigener] [char](2) NULL,
		[des_trigener] [char](45) NULL
	)
	ALTER TABLE DESA.[tb_tributo]
	ADD id_entidad int NOT NULL
	GO
	ALTER TABLE desa.[tb_tributo]
	ADD id_infraccion int not null
	GO

	ALTER TABLE DESA.[tb_tributo]  WITH CHECK ADD  CONSTRAINT [FK_TB_ENTIDAD] FOREIGN KEY([id_entidad])
	REFERENCES DESA.[tb_entidad] ([id_entidad])
	GO
	ALTER TABLE DESA.[tb_tributo]  WITH CHECK ADD  CONSTRAINT [FK_TB_INFRACCION] FOREIGN KEY([id_infraccion])
	REFERENCES DESA.[tb_infraccion] ([id_infraccion])
	GO


/*******************************************************************************************************************************/
----------------------------------POBLANDO TABLA TB_ENTIDAD--------------------------------------------------------------

	INSERT INTO db_proc_cdp.desa.tb_entidad
	SELECT * FROM db_gpgd.DBO.param_tipo_entidad
	
	INSERT INTO db_proc_cdp.desa.tb_entidad
	SELECT 0,'NO DEFINIDO'
	
	

/*********************************************************************************************************************************/
-----------------------------------POBLANDO TABLA TB_INFRACCI�N-------------------------------------------------------

INSERT INTO desa.tb_infraccion
SELECT DISTINCT infrac_Articulo,infrac_Numeral,NULL,NULL,NULL,NULL
FROM db_gpgd.dbo.param_tributo


/**********************************************************************************************************************************/
--------------------------------------POBLANDO TABLA TB_TRIBUTO----------------------------------------------------------

		INSERT INTO desa.[tb_tributo]
		SELECT  cod_trib COLLATE SQL_Latin1_General_CP1_CI_AS,
				des_corta COLLATE SQL_Latin1_General_CP1_CI_AS,
				desctrib COLLATE SQL_Latin1_General_CP1_CI_AS,
				cod_subtri COLLATE SQL_Latin1_General_CP1_CI_AS,
				des_subtri COLLATE SQL_Latin1_General_CP1_CI_AS,
				cod_trigen COLLATE SQL_Latin1_General_CP1_CI_AS,
				des_trigen COLLATE SQL_Latin1_General_CP1_CI_AS,
				entidad,
				B.id_infraccion
		FROM db_gpgd.dbo.param_tributo  A 
		LEFT JOIN db_proc_cdp.desa.tb_infraccion B ON A.infrac_articulo=B.art_infraccion AND A.infrac_Numeral=B.num_infraccion
		WHERE cod_trib NOT IN (
								SELECT cod_trib COLLATE SQL_Latin1_General_CP1_CI_AS FROM db_gpgd.dbo.param_tributo
								EXCEPT
								SELECT distinct cod_tributo FROM db_proc_cdp.DBO.d2712dimtrib
							  )
		UNION ALL
		SELECT cod_tributo,des_sigtributo,des_tributo,cod_subtri,des_subtri,cod_trigener,des_trigener,'0' as entidad,0
		FROM db_proc_cdp.DBO.d2712dimtrib
		WHERE cod_tributo IN (
								SELECT distinct cod_tributo FROM db_proc_cdp.DBO.d2712dimtrib
								EXCEPT
								SELECT cod_trib COLLATE SQL_Latin1_General_CP1_CI_AS FROM db_gpgd.dbo.param_tributo
							 ) AND cod_tributo<>'06080'

/*************************************************************************************************************************************/

------------------VISTA PARA DIM_TRIBUTO(LA DIMENSION TRIBUTO TIENE INFORMACION DE ENTIDAD E INFRACCION)--------------------------------

SELECT A.*,B.desc_entidad as Entidad,C.art_infraccion AS [Art�culo Infracci�n],C.num_infraccion AS [Numeral Infracci�n]
FROM desa.[tb_tributo] A 
INNER JOIN desa.tb_entidad B	ON A.id_entidad=B.id_entidad
INNER JOIN desa.tb_infraccion C ON A.id_infraccion=C.id_infraccion


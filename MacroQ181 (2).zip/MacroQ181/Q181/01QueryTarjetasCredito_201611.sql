Select * from db_selec_desa.dbo.tbl_pco_var
where cod_var in ('Q181')

Select * from db_selec_desa.dbo.tbl_pco_subvar
where cod_sv in (Select cod_sv from db_selec_desa.dbo.tbl_pco_var_subvar
where cod_var in ('Q181'))
ORDER BY 1 

/****************************************************************Q181****************************************************************/
/******************************************************************/
--S768 - Ingresos Renta Mensual Anualizado
/*
SELECT   sum(djb.valor_casilla*1)
FROM     informix.djbp_2003 djb,
         informix.vw_cab_unicas vw_
WHERE    ( vw_.cic = ?
     AND (vw_.periodo between '?PerIni' and '?PerFin')
     AND (vw_.tributo in ('030301','031101')))
AND      (djb.nota_abono=vw_.nabono
     AND djb.formulario=vw_.formulario
     AND djb.n_orden=vw_.nro_orden
     AND djb.casilla ='301')
*/

DROP TABLE db_col11.dbo.Univ_TCredito_DetIGVTemp
GO

SELECT vw_.cic, vw_.formulario, vw_.periodo, vw_.tributo, djb.casilla, djb.valor_casilla
INTO  db_col11.dbo.Univ_TCredito_DetIGVTemp
FROM     DB_TERADATA.DBO.POC_IGV_DET_F0621 djb,
         DB_TERADATA.DBO.POC_IGV_cab_F0621 vw_
WHERE    (vw_.cic = vw_.cic)
AND      (vw_.periodo >= '201601'
     AND vw_.periodo <= '201608')
AND      (djb.nota_abono=vw_.nabono
     AND djb.formulario = vw_.formulario
     AND djb.n_orden=vw_.nro_orden)
AND    ((vw_.tributo='030301' and djb.casilla in ('301')) 
	OR (vw_.tributo='031101' and djb.casilla in ('301')))
GO
--(10277864 row(s) affected) - 2016


DROP TABLE db_col11.dbo.UnivTarjCredito_S768
GO

SELECT a.cic
, sum(case when casilla in ('301') then cast((CASE WHEN ISNUMERIC(valor_casilla)=0 THEN '0' ELSE valor_casilla END) as decimal(15,2)) else 0.0 end) as T054
INTO db_col11.dbo.UnivTarjCredito_S768
FROM db_col11.dbo.Univ_TCredito_DetIGVTemp a 
group by a.cic
go
--(1040840 row(s) affected) - 2016

/******************************************************************/
--T440 - Rentas de cuarta categor�a declaradas mensualmente
/*
SELECT sum(djb.valor_casilla *1) 
FROM informix.djbp_2003 djb, informix.vw_cab_unicas vw_ 
WHERE (vw_.cic = ? 
            AND (vw_.periodo >= '?PerIni' AND vw_.periodo <= '?PerFin' ) 
    AND vw_.tributo = '030401') 
AND (djb.nota_abono=vw_.nabono AND djb.formulario = vw_.formulario 
     AND djb.n_orden=vw_.nro_orden) 
AND djb.casilla in ('307')
*/
DROP TABLE DB_COL11.DBO.UnivTarjCredito_T440
GO

SELECT vw_.cic, sum(cast(djb.valor_casilla as decimal(15,0))*1) as T440
INTO DB_COL11.DBO.UnivTarjCredito_T440
FROM DB_COL11.DBO.UnivTarjCredito_0616 djb, DB_COL11.DBO.UnivTarjCredito_0616_Cab vw_ 
WHERE (vw_.cic = vw_.cic 
            AND (vw_.periodo >= '201601' AND vw_.periodo <= '201608' ) 
    AND vw_.tributo = '030401') 
AND (djb.nota_abono=vw_.nabono AND djb.formulario = vw_.formulario 
     AND djb.n_orden=vw_.nro_orden) 
AND djb.casilla in ('307')
GROUP BY vw_.cic
GO
--(22433 row(s) affected) - 2016

/******************************************************************/
--T606 - Monto de Ventas realizadas con tarjetas de credito o debito - DETALLE
/*
Select SUM(cast(MONTO as decimal(20,2))/D.inc_igv)
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = ?  AND A.ANIO+A.PERIODO between '?PerIni' and '?PerFin'
*/

DROP TABLE DB_COL11.DBO.UnivTarjCredito_T606
GO

Select A.cic, SUM(cast(MONTO as decimal(20,2))/D.inc_igv) AS T606
into DB_COL11.DBO.UnivTarjCredito_T606
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = A.cic  AND A.ANIO+A.PERIODO between '201601' and '201608'
group by A.cic
go
--(67624 row(s) affected) - 2016

/******************************************************************/
--T627 - Ingresos o Compras Estimadas en el RUS
/*
SELECT   sum(case 
		when valor_casilla ='1' then 5000 
		else (case 
		when valor_casilla ='2' then 8000 
		else (case 
		when valor_casilla ='3' then 13000 
		else (case 
		when valor_casilla ='4' then 20000 
		else (case 
		when valor_casilla ='5' then 30000 
		else 13000 end) 
		end)  end)  end)  end) 
FROM     informix.djbp_2003 
WHERE    cic = ? 
AND      formulario = '1611' 
AND      periodo between '?PerIni' and  '?PerFin' 
AND      casilla = '400'
*/

--ESTA VARIABLE SE PUEDE OBTENBER DESDE LA SUBVARIABLE DE CAMPA�A RUS
DROP TABLE DB_COL11.DBO.UnivTarjCredito_T627
GO

SELECT * INTO DB_COL11.DBO.UnivTarjCredito_T627 FROM DB_COL11.DBO.UnivCampRUS_S952 
GO
--(640432 row(s) affected) - 2016 

--SINO EJCUTAR DESDE LO DESCARGADO
DROP TABLE DB_COL11.DBO.UnivTarjCredito_T627
GO

SELECT  cic,  sum(case 
		when valor_casilla ='1' then 5000 
		else (case 
		when valor_casilla ='2' then 8000 
		else (case 
		when valor_casilla ='3' then 13000 
		else (case 
		when valor_casilla ='4' then 20000 
		else (case 
		when valor_casilla ='5' then 30000 
		else 13000 end) 
		end)  end)  end)  end) S952
INTO DB_COL11.DBO.UnivTarjCredito_T627
FROM DB_COL11.DBO.UnivTarjCredito_1611
GROUP BY cic
GO

/******************************************************************/
--T921 - Proyecci�n de ventas (con un supuesto de 40% de ventas al contado)
/*
Select SUM(cast(MONTO as decimal(20,2))/D.inc_igv)*1.6667
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = ?  AND A.ANIO='?Anio'
*/

Select A.cic, SUM(cast(MONTO as decimal(20,2))/D.inc_igv)*1.6667
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = A.cic  AND A.ANIO='2016'
GROUP BY A.cic


SELECT ANIO, PERIODO, COUNT(*) FROM DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES
GROUP BY ANIO, PERIODO
ORDER BY 1,2

--====CONTINUACION
drop table DB_COL1.DBO.UnivTarjCredito_T921
Select A.cic, SUM(cast(MONTO as decimal(20,2))/D.inc_igv)*1.6667 AS T921
INTO DB_COL1.DBO.UnivTarjCredito_T921
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = A.cic  AND  A.ANIO+A.PERIODO between '201601' and '201603'
GROUP BY A.cic
--(64653 filas afectadas)



/******************************************************************************/
--CONSOLIDAR CIC'S

DROP TABLE DB_COL1.DBO.UnivTarjCredito_CIC
GO

CREATE TABLE DB_COL1.DBO.UnivTarjCredito_CIC(CIC INT NOT NULL)
GO

INSERT INTO DB_COL1.DBO.UnivTarjCredito_CIC

SELECT CIC FROM DB_COL1.DBO.UnivTarjCredito_S768 WHERE CIC<>0
UNION
SELECT CIC FROM DB_COL1.DBO.UnivTarjCredito_T440 WHERE CIC<>0
UNION
SELECT CIC FROM DB_COL1.DBO.UnivTarjCredito_T606 WHERE CIC<>0
UNION
SELECT CIC FROM DB_COL1.DBO.UnivTarjCredito_T627 WHERE CIC<>0
UNION
SELECT CIC FROM DB_COL1.DBO.UnivTarjCredito_T921 WHERE CIC<>0
GO

--(1538295 filas afectadas) 

/******************************************************************************/


SELECT x0.CIC, 
isnull(x2.S768,0) AS S768, 
isnull(x3.T440,0) AS T440, 
isnull(x4.T606,0) AS T606, 
isnull(x5.T627,0) AS T627, 
isnull(x6.T921,0) AS T921

INTO  Db_COL1.DBO.UnivTarjCredito
FROM Db_COL1.DBO.UnivTarjCredito_CIC x0 
LEFT JOIN Db_COL1.DBO.UnivTarjCredito_S768 x2
ON x0.CIC=x2.CIC
LEFT JOIN Db_COL1.DBO.UnivTarjCredito_T440 x3
ON x0.CIC=x3.CIC
LEFT JOIN Db_COL1.DBO.UnivTarjCredito_T606 x4
ON x0.CIC=x4.CIC
LEFT JOIN Db_COL1.DBO.UnivTarjCredito_T627 x5
ON x0.CIC=x5.CIC
LEFT JOIN Db_COL1.DBO.UnivTarjCredito_T921 x6
ON x0.CIC=x6.CIC

GO

--(1538295 filas afectadas)

---Variable Q181

SELECT 
A.CIC, B.RUC, A.S768, A.T440, A.T606, A.T627, A.T921, 
--Q181
(CASE WHEN T921> (CASE WHEN (CASE WHEN S768> T627 THEN S768 ELSE T627 END) > T440 THEN (CASE WHEN S768> T627 THEN S768 ELSE T627 END) ELSE T440 END)
THEN T921 - (CASE WHEN (CASE WHEN S768> T627 THEN S768 ELSE T627 END) > T440 THEN (CASE WHEN S768> T627 THEN S768 ELSE T627 END) ELSE T440 END) 
ELSE 0 END) AS Q181
INTO  Db_COL1.DBO.UnivTarjCredito_Var
FROM DB_COL1.DBO.UnivTarjCredito A INNER JOIN DB_PADRON.DBO.TBL_GPGF_PADRON_RUC B
ON A.CIC=B.CIC
GO

--(1542148 filas afectadas) 00:14 MIN - 2016

----cic con mas de un ruc----
SELECT CIC,COUNT(*) FROM DB_COL1.DBO.UnivTarjCredito_Var
GROUP BY CIC HAVING COUNT(*)>1
ORDER BY 2 desc

--VARIABLE FINAL---
SELECT * FROM Db_COL1.DBO.UnivTarjCredito_Var


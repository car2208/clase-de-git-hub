/*------------------------------------------------------------------------------------------------------*/
/**************************--------------------RUS----------------------*********************************/
/*------------------------------------------------------------------------------------------------------*/
--POR ESTA DESCARGA TAMBIEN SE PUEDE USAR LA DESCARGA DE DETECCION TEMPRANA
--RUS
select  x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,
x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta ,x1.cod_casilla casilla ,x1.mto_casilla valor_casilla , x1.cod_veredito cod_veredito
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1 
where (x0.cod_formul = "1611" and (x0.num_periodo >="201601" and x0.num_periodo <="201603"))
and ((x0.num_nabono = x1.num_nabono and x0.cod_formul = x1.cod_formul  and x0.num_orden = x1.num_orden)
and x1.cod_casilla in ("400"))
--1599338 rows of data written to D:\FORMULARIOS\1611_Vert\Univ_IPNJ_A�oAct_Rus_20160103.txt (5604.60 secs)
--1588715 rows of data written to D:\FORMULARIOS\1611_Vert\Univ_IPNJ_A�oAct_Rus_20160406.txt (3883.30 secs)
--1032810 rows of data written to D:\FORMULARIOS\1611_Vert\Univ_IPNJ_A�oAct_Rus_20160708.txt (3214.57 secs)

/*------------------------------------------------------------------------------------------------------*/
/**************************--------------------0616---------------------*********************************/
/*------------------------------------------------------------------------------------------------------*/

--0616
select  x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,
x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta ,x1.cod_casilla casilla ,x1.mto_casilla valor_casilla , x1.cod_veredito cod_veredito
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1 
where (x0.cod_formul = "0616" and (x0.num_periodo >="201601" and x0.num_periodo <="201603"))
and ((x0.num_nabono = x1.num_nabono and x0.cod_formul = x1.cod_formul  and x0.num_orden = x1.num_orden)
and x1.cod_casilla in (307))
--41030 rows of data written to D:\FORMULARIOS\0616_Vert\Univ_IPNJ_A�oAct_0616_20160103.txt (302.50 secs)
--43242 rows of data written to D:\FORMULARIOS\0616_Vert\Univ_IPNJ_A�oAct_0616_20160406.txt (238.83 secs)
--28795 rows of data written to D:\FORMULARIOS\0616_Vert\Univ_IPNJ_A�oAct_0616_20160708.txt (169.29 secs)

-------------------------
--0616
select   * from     informix.vw_cab_unicas 
where    formulario = '0616' and      periodo >="201601"  and periodo <="201608"
--375996 rows of data written to D:\FORMULARIOS\0616_Vert\vw_cab_unicas_0616_20160108.txt (168.20 secs)


/********************************************************************************************************/
-----------------------CREAMOS LAS TABLAS DE LAS DESCARGAS REALIZADAS DEL INFORMIX-----------------------
/********************************************************************************************************/
--TABLAS RUS

DROP TABLE DB_COL11.DBO.UnivTarjCredito_1611
GO
CREATE TABLE DB_COL11.DBO.UnivTarjCredito_1611
(nota_abono VARCHAR(8),
formulario VARCHAR(4),
n_orden INT,
periodo VARCHAR(6),
cic INT,
tipo_doc_declado SMALLINT,
n_doc_declado VARCHAR(15),
f_presenta DATE,
casilla VARCHAR(3),
valor_casilla VARCHAR(15),
cod_veredito CHAR(1)
)
GO

--TABLAS 0616

DROP TABLE DB_COL11.DBO.UnivTarjCredito_0616
GO
CREATE TABLE DB_COL11.DBO.UnivTarjCredito_0616
(nota_abono VARCHAR(8),
formulario VARCHAR(4),
n_orden INT,
periodo VARCHAR(6),
cic INT,
tipo_doc_declado SMALLINT,
n_doc_declado VARCHAR(15),
f_presenta DATE,
casilla VARCHAR(3),
valor_casilla VARCHAR(15),
cod_veredito CHAR(1)
)
GO

DROP TABLE DB_COL11.DBO.UnivTarjCredito_0616_Cab
GO
Create table DB_COL11.dbo.UnivTarjCredito_0616_Cab (
    cic                            int                            not null,
    periodo                        VARCHAR(7)                     not null,
    tributo                        CHAR(6)                        not null,
    nabono                         CHAR(8)                        null,
    formulario                     CHAR(4)                        null,
    nro_orden                      int                            null) 
GO


/********************************************************************************************************/
-------------------------OPCION DE CARGA CON BULK SINO UTILIZAR LA HERRAMIENTA DTS-----------------------
--------------------------SI NO TENEMOS PERMISOS PARA EJECUTAR BULK UTILIZAR DTS-------------------------
/********************************************************************************************************/

--CARGA RUS

BULK INSERT DB_COL11.DBO.UnivTarjCredito_1611 FROM 'G:\INCT\InfoInsi\IPNJ\Univ_IPNJ_A�oAct_Rus_20160103.txt'
WITH (FIRSTROW =2, FIELDTERMINATOR = '|',ROWTERMINATOR='\n',CODEPAGE='ACP');--'\t'
GO

BULK INSERT DB_COL11.DBO.UnivTarjCredito_1611 FROM 'G:\INCT\InfoInsi\IPNJ\Univ_IPNJ_A�oAct_Rus_20160406.txt'
WITH (FIRSTROW =2, FIELDTERMINATOR = '|',ROWTERMINATOR='\n',CODEPAGE='ACP');--'\t'
GO

BULK INSERT DB_COL11.DBO.UnivTarjCredito_1611 FROM 'G:\INCT\InfoInsi\IPNJ\Univ_IPNJ_A�oAct_Rus_20160708.txt'
WITH (FIRSTROW =2, FIELDTERMINATOR = '|',ROWTERMINATOR='\n',CODEPAGE='ACP');--'\t'
GO

BULK INSERT DB_COL11.DBO.UnivTarjCredito_1611 FROM 'G:\INCT\InfoInsi\IPNJ\Univ_IPNJ_A�oAct_Rus_20140103.txt'
WITH (FIRSTROW =2, FIELDTERMINATOR = '|',ROWTERMINATOR='\n',CODEPAGE='ACP');--'\t'
GO

--CARGA 0616

BULK INSERT DB_COL11.DBO.UnivTarjCredito_0616 FROM 'G:\INCT\InfoInsi\IPNJ\Univ_IPNJ_A�oAct_0616_20160103.txt'
WITH (FIRSTROW =2, FIELDTERMINATOR = '|',ROWTERMINATOR='\n',CODEPAGE='ACP');--'\t'
GO

BULK INSERT DB_COL11.DBO.UnivTarjCredito_0616 FROM 'G:\INCT\InfoInsi\IPNJ\Univ_IPNJ_A�oAct_0616_20160406.txt'
WITH (FIRSTROW =2, FIELDTERMINATOR = '|',ROWTERMINATOR='\n',CODEPAGE='ACP');--'\t'
GO

BULK INSERT DB_COL11.DBO.UnivTarjCredito_0616 FROM 'G:\INCT\InfoInsi\IPNJ\Univ_IPNJ_A�oAct_0616_20160708.txt'
WITH (FIRSTROW =2, FIELDTERMINATOR = '|',ROWTERMINATOR='\n',CODEPAGE='ACP');--'\t'
GO

BULK INSERT DB_COL11.DBO.UnivTarjCredito_0616_Cab FROM 'G:\INCT\InfoInsi\IPNJ\vw_cab_unicas_0616_20160108.txt'
WITH (FIRSTROW =2, FIELDTERMINATOR = '|',ROWTERMINATOR='\n',CODEPAGE='ACP');--'\t'
GO
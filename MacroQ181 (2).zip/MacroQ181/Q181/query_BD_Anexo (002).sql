/*
SELECT * FROM DB_SELEC_DESA.dbo.tbl_pco_VAR 
WHERE cod_var='Q181'


--(CASE WHEN ~T921> (CASE WHEN (CASE WHEN ~S768> ~T627 THEN ~S768 ELSE ~T627 END) > ~T440 THEN (CASE WHEN ~S768> ~T627 THEN ~S768 ELSE ~T627 END) ELSE ~T440 END)
--THEN ~T921 - (CASE WHEN (CASE WHEN ~S768> ~T627 THEN ~S768 ELSE ~T627 END) > ~T440 THEN (CASE WHEN ~S768> ~T627 THEN ~S768 ELSE ~T627 END) ELSE ~T440 END) 
--ELSE 0 END)

SELECT * FROM DB_SELEC_DESA.dbo.tbl_pco_SUBVAR
WHERE COD_SV IN (
SELECT COD_SV FROM DB_SELEC_DESA.dbo.tbl_pco_VAR_SUBVAR
WHERE cod_var='Q181')
order by 1 

SELECT * FROM DB_SELEC_DESA.dbo.tbl_pco_QUERYREP
WHERE COD_QUERYREP IN (
	SELECT COD_QUERYREP FROM DB_SELEC_DESA.dbo.tbl_pco_SUBVAR WHERE COD_SV IN (
			SELECT COD_SV FROM DB_SELEC_DESA.dbo.tbl_pco_VAR_SUBVAR WHERE cod_var='Q181')
					)
*/

/*
--T440 - Rentas de cuarta categor�a declaradas mensualmente	
SELECT sum(djb.valor_casilla *1) 
FROM informix.djbp_2003 djb, informix.vw_cab_unicas vw_ 
WHERE (vw_.cic = ? 
            AND (vw_.periodo >= '?PerIni' AND vw_.periodo <= '?PerFin' ) 
    AND vw_.tributo = '030401') 
AND (djb.nota_abono=vw_.nabono AND djb.formulario = vw_.formulario 
     AND djb.n_orden=vw_.nro_orden) 
AND djb.casilla in ('307')

--T606 - Monto de Ventas realizadas con tarjetas de credito o debito - PROVISIONAL	
Select SUM(cast(MONTO as decimal(20,2))/D.inc_igv)
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = ?  AND A.ANIO+A.PERIODO between '?PerIni' and '?PerFin'

--T921 - Proyecci�n de ventas (con un supuesto de 40% de ventas al contado)	
Select SUM(cast(MONTO as decimal(20,2))/D.inc_igv)*1.6667
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = ?  AND A.ANIO='?Anio'

--T627 - Ingresos o Compras Estimadas en el RUS	
SELECT   sum(case 
		when valor_casilla ='1' then 5000 
		else (case 
		when valor_casilla ='2' then 8000 
		else (case 
		when valor_casilla ='3' then 13000 
		else (case 
		when valor_casilla ='4' then 20000 
		else (case 
		when valor_casilla ='5' then 30000 
		else 13000 end) 
		end)  end)  end)  end) 
FROM     informix.djbp_2003 
WHERE    cic = ? 
AND      formulario = '1611' 
AND      periodo between '?PerIni' and  '?PerFin' 
AND      casilla = '400'

--S768 - Ingresos Renta Mensual Anualizado	
SELECT   sum(djb.valor_casilla*1)
FROM     informix.djbp_2003 djb,
         informix.vw_cab_unicas vw_
WHERE    ( vw_.cic = ?
     AND (vw_.periodo between '?PerIni' and '?PerFin')
     AND (vw_.tributo in ('030301','031101')))
AND      (djb.nota_abono=vw_.nabono
     AND djb.formulario=vw_.formulario
     AND djb.n_orden=vw_.nro_orden
     AND djb.casilla ='301')
*/

/*
--DESCARGAS
select  x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,
x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta ,x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1 
where (x0.cod_formul = "1611" and (x0.num_periodo between "201503"  and "201504"))
and ((x0.num_nabono = x1.num_nabono and x0.cod_formul = x1.cod_formul  and x0.num_orden = x1.num_orden)   
and x1.cod_casilla in ("400"))
--977713 rows of data written to D:\FORMULARIOS\1611_Vert\Det1611_Cas400_20150102.txt (1029.95 secs)
--988672 rows of data written to D:\FORMULARIOS\1611_Vert\Det1611_Cas400_20150304.txt (1724.66 secs)
--998811 rows of data written to D:\FORMULARIOS\1611_Vert\Det1611_Cas400_20150506.txt (2188.65 secs)
--1013407 rows of data written to D:\FORMULARIOS\1611_Vert\Det1611_Cas400_20150708.txt (2191.93 secs)
--1023360 rows of data written to D:\FORMULARIOS\1611_Vert\Det1611_Cas400_20150910.txt (1968.79 secs)
--1027195 rows of data written to D:\FORMULARIOS\1611_Vert\Det1611_Cas400_20151112.txt (2527.34 secs)

select  x0.num_nabono nota_abono ,x0.cod_formul formulario ,x0.num_orden n_orden ,x0.num_periodo periodo ,
x0.cod_cic cic ,x0.cod_tipidenti tipo_doc_declado ,x0.num_docidenti n_doc_declado ,
x0.fec_presenta f_presenta ,x1.cod_casilla casilla ,x1.mto_casilla valor_casilla 
from sif:admdwh.t2782djcab x0 ,sif:admdwh.t2783djdet x1 
where (x0.cod_formul = "0616" and (x0.num_periodo [1,4] ="2015" ))
and ((x0.num_nabono = x1.num_nabono and x0.cod_formul = x1.cod_formul  and x0.num_orden = x1.num_orden)   
and x1.cod_casilla in ("307"))
--173149 rows of data written to D:\FORMULARIOS\0616_Vert\Det0616_cas307_2015.txt (1426.17 secs)

Select * from informix.vw_cab_unicas
where formulario='0616' and periodo[1,4]='2015' and tributo='030401' 
--200994 rows of data written to D:\FORMULARIOS\0616_Vert\Cab0616_2015_030401.txt (109.78 secs)

DROP TABLE DB_COL11.dbo.PED8121_DET_DJ
GO

Create table DB_COL11.dbo.PED8121_DET_DJ (
    nota_abono                     CHAR(8)                        not null,
    formulario                     CHAR(4)                        not null,
    n_orden                        int                            not null,
    periodo                        CHAR(6)                        null,
    cic                            int                            not null,
    tipo_doc_declado               smallint                       not null,
    n_doc_declado                  VARCHAR(15)                    not null,
    f_presenta                     date                           null,
    casilla                        CHAR(3)                        not null,
    valor_casilla                  VARCHAR(15)                    null) 
GO

DROP TABLE DB_COL11.dbo.PED8121_CAB_DJ
GO

Create table DB_COL11.dbo.PED8121_CAB_DJ (
cic			INT			NOT NULL,
periodo		VARCHAR(7)	NOT NULL,
tributo		CHAR(6)		NOT NULL,
nabono		CHAR(8)		NULL,
formulario	CHAR(4)		NULL,
nro_orden	INT			NULL) 
GO

*/

--S768	Ingresos Renta Mensual Anualizado
	
DROP TABLE DB_COL11.DBO.PED8121_S768_TEMP
GO

SELECT   vw_.cic, sum(CASE WHEN ISNUMERIC(valor_casilla)=0 THEN 0.0 ELSE cast(valor_casilla as decimal(15,2))*1 END) AS S768
INTO DB_COL11.DBO.PED8121_S768_TEMP
FROM     db_teradata.dbo.POC_IGV_DET_F0621 djb,
         db_teradata.dbo.POC_IGV_CAB_F0621 vw_
WHERE    ( vw_.cic = vw_.cic
     AND (vw_.periodo between '201501' and '201512')
     AND (vw_.tributo in ('030301','031101')))
AND      (djb.nota_abono=vw_.nabono
     AND djb.formulario=vw_.formulario
     AND djb.n_orden=vw_.nro_orden
     AND djb.casilla ='301')
GROUP BY vw_.cic
GO

INSERT INTO DB_COL11.DBO.PED8121_S768_TEMP
SELECT   vw_.cic, sum(CASE WHEN ISNUMERIC(valor_casilla)=0 THEN 0.0 ELSE cast(valor_casilla as decimal(15,2))*1 END) AS S768
FROM     db_teradata.dbo.POC_IGV_DET_F0119 djb,
         db_teradata.dbo.POC_IGV_CAB_F0119 vw_
WHERE    ( vw_.cic = vw_.cic
     AND (vw_.periodo between '201501' and '201512')
     AND (vw_.tributo in ('030301','031101')))
AND      (djb.nota_abono=vw_.nabono
     AND djb.formulario=vw_.formulario
     AND djb.n_orden=vw_.nro_orden
     AND djb.casilla ='301')
GROUP BY vw_.cic
GO

INSERT INTO DB_COL11.DBO.PED8121_S768_TEMP
SELECT   vw_.cic, sum(CASE WHEN ISNUMERIC(valor_casilla)=0 THEN 0.0 ELSE cast(valor_casilla as decimal(15,2))*1 END) AS S768
FROM     db_teradata.dbo.POC_IGV_DET_F0118 djb,
         db_teradata.dbo.POC_IGV_CAB_F0118 vw_
WHERE    ( vw_.cic = vw_.cic
     AND (vw_.periodo between '201501' and '201512')
     AND (vw_.tributo in ('030301','031101')))
AND      (djb.nota_abono=vw_.nabono
     AND djb.formulario=vw_.formulario
     AND djb.n_orden=vw_.nro_orden
     AND djb.casilla ='301')
GROUP BY vw_.cic
GO

DROP TABLE DB_COL11.DBO.PED8121_S768
GO

SELECT CIC, SUM(S768) AS S768
INTO DB_COL11.DBO.PED8121_S768
FROM DB_COL11.DBO.PED8121_S768_TEMP
GROUP BY CIC

DROP TABLE DB_COL11.DBO.PED8121_S768_TEMP
GO

--T440	Rentas de cuarta categor�a declaradas mensualmente	
DROP TABLE DB_COL11.DBO.PED8121_T440
GO

SELECT vw_.cic, sum(CASE WHEN ISNUMERIC(valor_casilla)=0 THEN 0.0 ELSE cast(valor_casilla as decimal(15,2))*1 END) AS T440
INTO DB_COL11.DBO.PED8121_T440
FROM DB_COL11.dbo.PED8121_DET_DJ djb, DB_COL11.dbo.PED8121_CAB_DJ vw_ 
WHERE (vw_.cic = vw_.cic 
            AND (vw_.periodo >= '201501' AND vw_.periodo <= '201512' ) 
    AND vw_.tributo = '030401') 
AND (djb.nota_abono=vw_.nabono AND djb.formulario = vw_.formulario 
     AND djb.n_orden=vw_.nro_orden) 
AND djb.casilla in ('307')
GROUP BY vw_.cic
GO

--T606	- Monto de Ventas realizadas con tarjetas de credito o debito - PROVISIONAL	
DROP TABLE DB_COL11.DBO.PED8121_T606
GO

Select A.cic, SUM(cast(MONTO as decimal(20,2))/D.inc_igv) as T606
INTO DB_COL11.DBO.PED8121_T606
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = A.cic  AND A.ANIO+A.PERIODO between '201501' and '201512'
group by A.cic
GO

--T627	Ingresos o Compras Estimadas en el RUS	
DROP TABLE DB_COL11.DBO.PED8121_T627
GO

SELECT  cic, sum(case 
		when valor_casilla ='1' then 5000 
		else (case 
		when valor_casilla ='2' then 8000 
		else (case 
		when valor_casilla ='3' then 13000 
		else (case 
		when valor_casilla ='4' then 20000 
		else (case 
		when valor_casilla ='5' then 30000 
		else 13000 end) 
		end)  end)  end)  end) AS T627
INTO DB_COL11.DBO.PED8121_T627
FROM     DB_COL11.DBO.PED8121_DET_DJ
WHERE    cic = cic 
AND      formulario = '1611' 
AND      periodo between '201501' and  '201512' 
AND      casilla = '400'
GROUP BY cic
GO 

--T921	Proyecci�n de ventas (con un supuesto de 40% de ventas al contado)	
DROP TABLE DB_COL11.DBO.PED8121_T921
GO

Select A.cic, SUM(cast(MONTO as decimal(20,2))/D.inc_igv)*1.6667 AS T921
INTO DB_COL11.DBO.PED8121_T921
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = A.cic  AND A.ANIO='2015'
GROUP BY A.cic

/******************************************************************/
--CONSOLIDAR
DROP TABLE DB_COL11.DBO.PED8121_CIC_SV
GO

SELECT X1.*, ISNULL(X2.S768,0) AS S768, ISNULL(X3.T440,0) AS T440, ISNULL(X4.T606,0) AS T606, ISNULL(X5.T627,0) AS T627, ISNULL(X6.T921,0) AS T921
, (CASE WHEN ISNULL(T921,0)> (CASE WHEN (CASE WHEN ISNULL(S768,0)> ISNULL(T627,0) THEN ISNULL(S768,0) ELSE ISNULL(T627,0) END) > ISNULL(T440,0) THEN (CASE WHEN ISNULL(S768,0)> ISNULL(T627,0) THEN ISNULL(S768,0) ELSE ISNULL(T627,0) END) ELSE ISNULL(T440,0) END)
THEN ISNULL(T921,0) - (CASE WHEN (CASE WHEN ISNULL(S768,0)> ISNULL(T627,0) THEN ISNULL(S768,0) ELSE ISNULL(T627,0) END) > ISNULL(T440,0) THEN (CASE WHEN ISNULL(S768,0)> ISNULL(T627,0) THEN ISNULL(S768,0) ELSE ISNULL(T627,0) END) ELSE ISNULL(T440,0) END) 
ELSE 0 END) AS Q181
INTO DB_COL11.DBO.PED8121_CIC_SV
FROM
(
SELECT CIC FROM DB_COL11.DBO.PED8121_S768
UNION
SELECT CIC FROM DB_COL11.DBO.PED8121_T440
UNION
SELECT CIC FROM DB_COL11.DBO.PED8121_T606
UNION
SELECT CIC FROM DB_COL11.DBO.PED8121_T627
UNION
SELECT CIC FROM DB_COL11.DBO.PED8121_T921
) X1
LEFT JOIN DB_COL11.DBO.PED8121_S768 X2
ON X1.cic=X2.CIC
LEFT JOIN DB_COL11.DBO.PED8121_T440 X3
ON X1.cic=X3.CIC
LEFT JOIN DB_COL11.DBO.PED8121_T606 X4
ON X1.cic=X4.CIC
LEFT JOIN DB_COL11.DBO.PED8121_T627 X5
ON X1.cic=X5.CIC
LEFT JOIN DB_COL11.DBO.PED8121_T921 X6
ON X1.cic=X6.CIC
WHERE X1.cic<>0

DROP TABLE DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
GO

SELECT 'NO' AS CIC_DUPLICADO, A.CIC, B.RUC, B.NOMBRE AS RAZON_SOCIAL
, ISNULL(C.cod_reg,'')+'-'+ISNULL(C.regional,'') AS DEPENDENCIA
, ISNULL(B.estado,'')+'-'+ISNULL(E.descestado,'') AS ESTADO
, ISNULL(B.CondDomicilio,'')+'-'+ISNULL(F.descconddomicilio,'') AS COND_DOMICILIO
, ISNULL(B.TipContrib,'')+'-'+ISNULL(G.descripcion,'') AS TIPO_CONTRIB
, ISNULL(B.ciiu,'')+'-'+ISNULL(D.descciiu,'') AS CIIU
, S768, T440, T606, T627, T921, Q181
INTO DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
FROM DB_COL11.DBO.PED8121_CIC_SV A 
LEFT JOIN DB_PADRON.DBO.TBL_GPGF_PADRON_RUC B
ON A.CIC=B.CIC
LEFT JOIN DB_PADRON.DBO.Param_gpgf_dependencia C
ON B.DEPENDENCIA=C.DEPENDENCIA
LEFT JOIN DB_PADRON.DBO.Param_gpgf_ciiu D
ON B.ciiu=D.ciiu
LEFT JOIN DB_PADRON.DBO.Param_gpgf_estado E
ON B.Estado=E.Estado
LEFT JOIN DB_PADRON.DBO.Param_gpgf_conddomicilio F
ON B.CondDomicilio=F.CondDomicilio
LEFT JOIN DB_PADRON.DBO.Param_gpgf_tipo_contrib G
ON B.TipContrib=G.codigo
GO

UPDATE DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
SET CIC_DUPLICADO='SI'
WHERE CIC IN (SELECT CIC FROM DB_COL11.DBO.PED8121_CIC_SV_VAR_PD GROUP BY CIC HAVING COUNT(*)>1)
GO


/*******************************************************/
ALTER TABLE DB_COL11.DBO.PED8121_CIC_SV_VAR_PD ADD PERIODO CHAR(4)
GO

UPDATE DB_COL11.DBO.PED8121_CIC_SV_VAR_PD 
SET PERIODO='2015'
GO

SELECT COUNT(*) FROM DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
WHERE Q181>1000
--10374


--EXPORTAR
SELECT * FROM DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
WHERE Q181>1000
--10374 rows of data written to D:\CESAR\PEDIDOS\8121 - FREDDY VILCHEZ SUAREZ - Q181\Ped8121_Q181_2015.txt (1.02 secs)

/*
	--Universo diferente de lima y mayor a mil
	select * from DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
	where substring(DEPENDENCIA,1,3)<>'002' and Q181>1000
	order by cic

	--para los anexos
	select PERIODO, S768, T440, T606, T627, T921, Q181 from DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
	where substring(DEPENDENCIA,1,3)<>'002' and Q181>1000 

	SELECT RAZON_SOCIAL, SUBSTRING(DEPENDENCIA,1,3) AS DEPENDENCIA FROM DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
*/


--AGREGAR CANTIDAD DE OPERACIONES
DROP TABLE DB_COL11.dbo.PED8121_INCT_TC_2015
GO 

SELECT * 
INTO DB_COL11.dbo.PED8121_INCT_TC_2015
FROM db_fuentes_Externas.dbo.TBL_INCT_TC_2015
--WHERE cic_establecimiento IN (select CIC from DB_COL11.DBO.PED8121_CIC_SV_VAR_PD where substring(DEPENDENCIA,1,3)<>'002' and Q181>1000)
WHERE cic_establecimiento IN (select CIC from DB_COL11.DBO.PED8121_CIC_SV_VAR_PD where Q181>1000)
GO
--(1355008 row(s) affected)
--(9096611 row(s) affected) 02:27 min 2015

DROP TABLE DB_COL11.DBO.PED8121_INCT_TC_2015_Acumulado
GO

SELECT cic_establecimiento, periodo as Peri_Oper
, COUNT(*) AS CANT_OPERACIONES
, SUM(case when tipo_moneda='D' then isnull(mto_operacion,0)*tipo_cambio else isnull(mto_operacion,0) end )as mto_operacion
into DB_COL11.DBO.PED8121_INCT_TC_2015_Acumulado
FROM DB_COL11.dbo.PED8121_INCT_TC_2015 t1
LEFT JOIN DB_PROCESADO.DBO.TBL_INCT_PERCO_TC_DIARIO T2 ON  ltrim(rtrim(T1.fec_operacion))=T2.fecha_inv 
WHERE est_operacion IN ('1','3') and right(fec_operacion,4)='2015' 
and right(fec_operacion,4)+left(fec_operacion,2) between '201501' and '201512'
GROUP BY cic_establecimiento, periodo
GO
--(18213 row(s) affected)
--(89086 row(s) affected) 00:22 min 2015

DROP TABLE DB_COL11.DBO.PED8121_CANT_OPE
GO

Select A.cic_establecimiento AS cic, A.Peri_Oper, A.CANT_OPERACIONES, SUM(cast(mto_operacion as decimal(20,2))/D.inc_igv) as MTO_OPE
INTO DB_COL11.DBO.PED8121_CANT_OPE
from DB_COL11.DBO.PED8121_INCT_TC_2015_Acumulado a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.Peri_Oper=D.PERIODO
WHERE
A.cic_establecimiento = A.cic_establecimiento  AND A.Peri_Oper between '201501' and '201512'
group by A.cic_establecimiento, A.Peri_Oper, A.CANT_OPERACIONES
GO
--(18213 row(s) affected)
--(89086 row(s) affected)

CREATE TABLE DB_COL11.DBO.PED8121_PERIODO (PERIODO CHAR(6))
INSERT INTO  DB_COL11.DBO.PED8121_PERIODO VALUES ('201501'),('201502'),('201503'),('201504'),('201505'),('201506'),('201507'),('201508'),('201509'),('201510'),('201511'),('201512')

/*
SELECT A.PERIODO, ISNULL(B.MTO_OPE,0.0) AS MTO_OPE, ISNULL(B.CANT_OPERACIONES,0.0) AS CANT_OPERACIONES FROM  DB_COL11.DBO.PED8121_PERIODO A  LEFT JOIN DB_COL11.DBO.PED8121_CANT_OPE B ON A.PERIODO=B.Peri_Oper
AND CIC IN (SELECT CIC FROM DB_PADRON.DBO.TBL_GPGF_PADRON_RUC WHERE RUC='10028486923')
ORDER BY A.PERIODO
 
select CIC, RUC, PERIODO, S768, T440, T606, T627, T921, Q181 from DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
where RUC='10028486923'
*/

/*
select RUC, PERIODO, S768, T440, T606, T627, T921, Q181 from DB_COL11.DBO.PED8121_CIC_SV_VAR_PD
where T921>0 AND  substring(DEPENDENCIA,1,3)<>'002' and Q181>1000


SELECT SUM(MONTO) FROM DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES 
WHERE CIC IN (SELECT CIC FROM DB_PADRON.DBO.TBL_GPGF_PADRON_RUC WHERE RUC='10002166823') AND ANIO='2015'

Select A.cic, SUM(cast(MONTO as decimal(20,2))/D.inc_igv)*1.6667 AS T921
from DB_PROCESADO.DBO.TBL_INCT_PERCO_TARJETAS_CREDITO_MES a INNER JOIN  DB_PROCESADO.DBO.TBL_INCT_PERCO_IGV AS D
ON
A.ANIO+A.PERIODO=D.PERIODO
WHERE
A.cic = 150306  AND A.ANIO='2015'
GROUP BY A.cic
*/

--PASAR LA MACRO A DB_PROGRAMADOR PARAQUE EL SR. VILCHEZ PUEDA GENERAR LOS ANEXOS CON LA MACRO
DROP TABLE db_DivSeleccion.DBO.PED8121_CIC_SV_VAR_PD
GO
SELECT * INTO db_DivSeleccion.DBO.PED8121_CIC_SV_VAR_PD FROM DB_COL11.DBO.PED8121_CIC_SV_VAR_PD WHERE Q181>1000
GO
DROP TABLE db_DivSeleccion.DBO.PED8121_PERIODO
GO
SELECT * INTO db_DivSeleccion.DBO.PED8121_PERIODO FROM DB_COL11.DBO.PED8121_PERIODO
GO
DROP TABLE db_DivSeleccion.DBO.PED8121_CANT_OPE
GO
SELECT * INTO db_DivSeleccion.DBO.PED8121_CANT_OPE FROM DB_COL11.DBO.PED8121_CANT_OPE
GO

--(10374 row(s) affected)
--(12 row(s) affected)
--(89086 row(s) affected)

SELECT * FROM db_DivSeleccion.DBO.PED8121_CIC_SV_VAR_PD

SELECT RAZON_SOCIAL, SUBSTRING(DEPENDENCIA,1,3) AS DEPENDENCIA FROM db_DivSeleccion.DBO.PED8121_CIC_SV_VAR_PD WHERE RUC='10418698972'

SELECT PERIODO, S768, T440, T606, T627, T921, Q181 FROM db_DivSeleccion.DBO.PED8121_CIC_SV_VAR_PD WHERE RUC='10418698972'

SELECT ISNULL(B.MTO_OPE,0.0) AS MTO_OPE, ISNULL(B.CANT_OPERACIONES,0.0) AS CANT_OPERACIONES 
FROM  db_DivSeleccion.DBO.PED8121_PERIODO A  LEFT JOIN db_DivSeleccion.DBO.PED8121_CANT_OPE B ON A.PERIODO=B.Peri_Oper
AND CIC IN (SELECT CIC FROM DB_PADRON.DBO.TBL_GPGF_PADRON_RUC WHERE RUC='10418698972')
ORDER BY A.PERIODO

